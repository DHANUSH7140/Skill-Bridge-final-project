import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Create Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-2c3d544b/health", (c) => {
  return c.json({ status: "ok" });
});

// ========== USER AUTHENTICATION ==========

// Signup endpoint
app.post("/make-server-2c3d544b/signup", async (c) => {
  try {
    const body = await c.req.json();
    const { email, password, fullName, phone, userType, category, address, aadharNumber } = body;

    if (!email || !password || !fullName) {
      return c.json({ error: "Email, password, and full name are required" }, 400);
    }

    // Create user with Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Auto-confirm since email server is not configured
      user_metadata: { 
        name: fullName,
        phone: phone || '',
      }
    });

    if (authError) {
      console.error("Signup error - Failed to create user in Supabase Auth:", authError);
      return c.json({ error: `Failed to create user: ${authError.message}` }, 400);
    }

    // Store additional user data in KV store
    const userData = {
      userId: authData.user.id,
      email,
      fullName,
      phone: phone || '',
      userType, // 'worker' or 'employer'
      category: category || '',
      address: address || '',
      aadharNumber: aadharNumber || '',
      profilePhoto: '',
      bio: '',
      skills: [],
      experience: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`user:${authData.user.id}`, userData);

    return c.json({ 
      success: true, 
      userId: authData.user.id,
      message: "User created successfully"
    });

  } catch (error) {
    console.error("Signup error - Unexpected error during signup:", error);
    return c.json({ error: `Signup failed: ${error.message}` }, 500);
  }
});

// Get user profile endpoint
app.get("/make-server-2c3d544b/user/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const userData = await kv.get(`user:${userId}`);

    if (!userData) {
      return c.json({ error: "User not found" }, 404);
    }

    return c.json({ user: userData });
  } catch (error) {
    console.error("Get user error - Failed to retrieve user profile:", error);
    return c.json({ error: `Failed to get user: ${error.message}` }, 500);
  }
});

// Update user profile endpoint
app.put("/make-server-2c3d544b/user/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const updates = await c.req.json();

    const userData = await kv.get(`user:${userId}`);
    if (!userData) {
      return c.json({ error: "User not found" }, 404);
    }

    const updatedUser = {
      ...userData,
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`user:${userId}`, updatedUser);

    return c.json({ success: true, user: updatedUser });
  } catch (error) {
    console.error("Update user error - Failed to update user profile:", error);
    return c.json({ error: `Failed to update user: ${error.message}` }, 500);
  }
});

// ========== JOB POSTS ==========

// Create post endpoint
app.post("/make-server-2c3d544b/posts", async (c) => {
  try {
    const body = await c.req.json();
    const { userId, postType, content, title, category, salary, location, requirements } = body;

    if (!userId || !content) {
      return c.json({ error: "User ID and content are required" }, 400);
    }

    const postId = crypto.randomUUID();
    const post = {
      id: postId,
      userId,
      postType: postType || 'general', // 'job', 'general', 'opportunity'
      title: title || '',
      content,
      category: category || '',
      salary: salary || '',
      location: location || '',
      requirements: requirements || [],
      likes: 0,
      comments: 0,
      shares: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`post:${postId}`, post);

    // Add to user's posts list
    const userPosts = await kv.get(`user_posts:${userId}`) || [];
    userPosts.unshift(postId);
    await kv.set(`user_posts:${userId}`, userPosts);

    return c.json({ success: true, post });
  } catch (error) {
    console.error("Create post error - Failed to create post:", error);
    return c.json({ error: `Failed to create post: ${error.message}` }, 500);
  }
});

// Get all posts endpoint
app.get("/make-server-2c3d544b/posts", async (c) => {
  try {
    const allPosts = await kv.getByPrefix('post:');
    
    // Sort by creation date (newest first)
    const sortedPosts = allPosts.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    // Get user data for each post
    const postsWithUserData = await Promise.all(
      sortedPosts.map(async (post) => {
        const user = await kv.get(`user:${post.userId}`);
        return {
          ...post,
          author: user ? {
            fullName: user.fullName,
            userType: user.userType,
            category: user.category,
          } : null,
        };
      })
    );

    return c.json({ posts: postsWithUserData });
  } catch (error) {
    console.error("Get posts error - Failed to retrieve posts:", error);
    return c.json({ error: `Failed to get posts: ${error.message}` }, 500);
  }
});

// Get user's posts endpoint
app.get("/make-server-2c3d544b/posts/user/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const userPostIds = await kv.get(`user_posts:${userId}`) || [];

    const posts = await Promise.all(
      userPostIds.map(async (postId) => {
        return await kv.get(`post:${postId}`);
      })
    );

    const validPosts = posts.filter(post => post !== null);

    return c.json({ posts: validPosts });
  } catch (error) {
    console.error("Get user posts error - Failed to retrieve user posts:", error);
    return c.json({ error: `Failed to get user posts: ${error.message}` }, 500);
  }
});

// Like/Unlike post endpoint
app.post("/make-server-2c3d544b/posts/:postId/like", async (c) => {
  try {
    const postId = c.req.param('postId');
    const { userId } = await c.req.json();

    const post = await kv.get(`post:${postId}`);
    if (!post) {
      return c.json({ error: "Post not found" }, 404);
    }

    const likeKey = `post_like:${postId}:${userId}`;
    const hasLiked = await kv.get(likeKey);

    if (hasLiked) {
      // Unlike
      await kv.del(likeKey);
      post.likes = Math.max(0, post.likes - 1);
    } else {
      // Like
      await kv.set(likeKey, true);
      post.likes += 1;
    }

    post.updatedAt = new Date().toISOString();
    await kv.set(`post:${postId}`, post);

    return c.json({ success: true, likes: post.likes, liked: !hasLiked });
  } catch (error) {
    console.error("Like post error - Failed to like/unlike post:", error);
    return c.json({ error: `Failed to like post: ${error.message}` }, 500);
  }
});

// ========== MESSAGING ==========

// Get conversations endpoint
app.get("/make-server-2c3d544b/conversations/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const conversations = await kv.get(`conversations:${userId}`) || [];

    return c.json({ conversations });
  } catch (error) {
    console.error("Get conversations error - Failed to retrieve conversations:", error);
    return c.json({ error: `Failed to get conversations: ${error.message}` }, 500);
  }
});

// Send message endpoint
app.post("/make-server-2c3d544b/messages", async (c) => {
  try {
    const { conversationId, senderId, content, type } = await c.req.json();

    if (!conversationId || !senderId || !content) {
      return c.json({ error: "Conversation ID, sender ID, and content are required" }, 400);
    }

    const messageId = crypto.randomUUID();
    const message = {
      id: messageId,
      conversationId,
      senderId,
      content,
      type: type || 'text',
      timestamp: new Date().toISOString(),
    };

    // Store message
    await kv.set(`message:${messageId}`, message);

    // Add to conversation messages
    const conversationMessages = await kv.get(`conversation_messages:${conversationId}`) || [];
    conversationMessages.push(messageId);
    await kv.set(`conversation_messages:${conversationId}`, conversationMessages);

    return c.json({ success: true, message });
  } catch (error) {
    console.error("Send message error - Failed to send message:", error);
    return c.json({ error: `Failed to send message: ${error.message}` }, 500);
  }
});

// Get messages for a conversation
app.get("/make-server-2c3d544b/messages/:conversationId", async (c) => {
  try {
    const conversationId = c.req.param('conversationId');
    const messageIds = await kv.get(`conversation_messages:${conversationId}`) || [];

    const messages = await Promise.all(
      messageIds.map(async (msgId) => {
        return await kv.get(`message:${msgId}`);
      })
    );

    const validMessages = messages.filter(msg => msg !== null);

    return c.json({ messages: validMessages });
  } catch (error) {
    console.error("Get messages error - Failed to retrieve messages:", error);
    return c.json({ error: `Failed to get messages: ${error.message}` }, 500);
  }
});

// ========== CONTACT FORM ==========

// Submit contact form
app.post("/make-server-2c3d544b/contact", async (c) => {
  try {
    const { name, email, subject, message } = await c.req.json();

    if (!name || !email || !message) {
      return c.json({ error: "Name, email, and message are required" }, 400);
    }

    const contactId = crypto.randomUUID();
    const contactSubmission = {
      id: contactId,
      name,
      email,
      subject: subject || 'No subject',
      message,
      status: 'new',
      createdAt: new Date().toISOString(),
    };

    await kv.set(`contact:${contactId}`, contactSubmission);

    return c.json({ success: true, message: "Contact form submitted successfully" });
  } catch (error) {
    console.error("Contact form error - Failed to submit contact form:", error);
    return c.json({ error: `Failed to submit contact form: ${error.message}` }, 500);
  }
});

// ========== JOB APPLICATIONS ==========

// Apply for a job
app.post("/make-server-2c3d544b/applications", async (c) => {
  try {
    const { jobPostId, applicantId, coverLetter } = await c.req.json();

    if (!jobPostId || !applicantId) {
      return c.json({ error: "Job post ID and applicant ID are required" }, 400);
    }

    const applicationId = crypto.randomUUID();
    const application = {
      id: applicationId,
      jobPostId,
      applicantId,
      coverLetter: coverLetter || '',
      status: 'pending', // pending, reviewed, accepted, rejected
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`application:${applicationId}`, application);

    // Add to job post applications
    const jobApplications = await kv.get(`job_applications:${jobPostId}`) || [];
    jobApplications.push(applicationId);
    await kv.set(`job_applications:${jobPostId}`, jobApplications);

    // Add to user's applications
    const userApplications = await kv.get(`user_applications:${applicantId}`) || [];
    userApplications.push(applicationId);
    await kv.set(`user_applications:${applicantId}`, userApplications);

    return c.json({ success: true, application });
  } catch (error) {
    console.error("Apply for job error - Failed to submit application:", error);
    return c.json({ error: `Failed to apply for job: ${error.message}` }, 500);
  }
});

// Get applications for a job post
app.get("/make-server-2c3d544b/applications/job/:jobPostId", async (c) => {
  try {
    const jobPostId = c.req.param('jobPostId');
    const applicationIds = await kv.get(`job_applications:${jobPostId}`) || [];

    const applications = await Promise.all(
      applicationIds.map(async (appId) => {
        const app = await kv.get(`application:${appId}`);
        if (app) {
          const applicant = await kv.get(`user:${app.applicantId}`);
          return {
            ...app,
            applicant: applicant ? {
              fullName: applicant.fullName,
              email: applicant.email,
              phone: applicant.phone,
              skills: applicant.skills,
            } : null,
          };
        }
        return null;
      })
    );

    const validApplications = applications.filter(app => app !== null);

    return c.json({ applications: validApplications });
  } catch (error) {
    console.error("Get job applications error - Failed to retrieve applications:", error);
    return c.json({ error: `Failed to get applications: ${error.message}` }, 500);
  }
});

// Get user's applications
app.get("/make-server-2c3d544b/applications/user/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const applicationIds = await kv.get(`user_applications:${userId}`) || [];

    const applications = await Promise.all(
      applicationIds.map(async (appId) => {
        const app = await kv.get(`application:${appId}`);
        if (app) {
          const jobPost = await kv.get(`post:${app.jobPostId}`);
          return {
            ...app,
            jobPost,
          };
        }
        return null;
      })
    );

    const validApplications = applications.filter(app => app !== null);

    return c.json({ applications: validApplications });
  } catch (error) {
    console.error("Get user applications error - Failed to retrieve user applications:", error);
    return c.json({ error: `Failed to get user applications: ${error.message}` }, 500);
  }
});

Deno.serve(app.fetch);
