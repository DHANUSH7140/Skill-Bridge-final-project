import { useState, useEffect } from "react";
import { Button } from "./components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./components/ui/card";
import { Input } from "./components/ui/input";
import { Textarea } from "./components/ui/textarea";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import { SimpleAuthModal } from "./components/SimpleAuthModal";
import { SkillFormModal } from "./components/SkillFormModal";
import { ImprovedHomePage } from "./components/ImprovedHomePage";
import { UserDashboard } from "./components/UserDashboard";
import { HomePage } from "./components/HomePage";
import { CreatePostPage } from "./components/CreatePostPage";
import { ChatSection } from "./components/ChatSection";
import { ProfileSection } from "./components/ProfileSection";
import { QuickActionsSection } from "./components/QuickActionsSection";
import { SettingsSection } from "./components/SettingsSection";
import { ConnectionsSection } from "./components/ConnectionsSection";
import { JobsSection } from "./components/JobsSection";
import { Sidebar } from "./components/Sidebar";
import { AuthFlowDiagram } from "./components/AuthFlowDiagram";
import { Toaster } from "./components/ui/sonner";
import { 
  Users, 
  Target, 
  CheckCircle, 
  UserCheck, 
  Lightbulb, 
  Shield,
  ArrowRight,
  Star,
  Mail,
  Phone,
  MapPin,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  Crown,
  Briefcase,
  Hammer,
  Wrench,
  GraduationCap,
  HandHeart,
  LogOut,
  Moon,
  Sun,
  Sparkles,
  TrendingUp,
  Award,
  Building2
} from "lucide-react";

export default function App() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [skillFormOpen, setSkillFormOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [showDashboard, setShowDashboard] = useState(false);
  const [activeTab, setActiveTab] = useState("home");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [theme, setTheme] = useState<"light" | "dark">("light");

  // Check for logged in user and theme on mount
  useEffect(() => {
    const userData = localStorage.getItem("skillbridge_user");
    if (userData) {
      const user = JSON.parse(userData);
      setCurrentUser(user);
      
      // Check if user needs to complete skill form
      if (user.needsSkillForm) {
        setSkillFormOpen(true);
      }
    }
    
    const savedTheme = localStorage.getItem("skillbridge_theme") as "light" | "dark" | null;
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.classList.toggle("dark", savedTheme === "dark");
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    localStorage.setItem("skillbridge_theme", newTheme);
    document.documentElement.classList.toggle("dark", newTheme === "dark");
  };

  const handleLogout = () => {
    localStorage.removeItem("skillbridge_user");
    setCurrentUser(null);
    setShowDashboard(false);
    setActiveTab("home");
    setSidebarOpen(false);
  };

  const openAuthModal = () => {
    setAuthModalOpen(true);
  };

  const handleAuthSuccess = () => {
    const userData = localStorage.getItem("skillbridge_user");
    if (userData) {
      const user = JSON.parse(userData);
      setCurrentUser(user);
      setShowDashboard(true);
      setActiveTab("home");
      
      // Check if user needs to complete skill form
      if (user.needsSkillForm) {
        setSkillFormOpen(true);
      }
    }
  };

  const handleSkillFormComplete = (updatedUser: any) => {
    setCurrentUser(updatedUser);
    setShowDashboard(true);
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setSidebarOpen(false);
  };

  const handleLogoClick = () => {
    if (currentUser && showDashboard) {
      setSidebarOpen(!sidebarOpen);
    }
  };

  const handleCreatePost = () => {
    setActiveTab("create-post");
  };

  // Render different content based on active tab
  const renderContent = () => {
    switch (activeTab) {
      case "home":
        return <ImprovedHomePage user={currentUser} onCreatePost={handleCreatePost} />;
      case "create-post":
        return <CreatePostPage user={currentUser} onBack={() => setActiveTab("home")} />;
      case "dashboard":
        return <UserDashboard user={currentUser} />;
      case "connections":
        return <ConnectionsSection user={currentUser} />;
      case "jobs":
        return <JobsSection user={currentUser} />;
      case "chat":
        return <ChatSection user={currentUser} />;
      case "profile":
        return <ProfileSection user={currentUser} />;
      case "quick-actions":
        return <QuickActionsSection user={currentUser} />;
      case "settings":
        return <SettingsSection />;
      default:
        return <ImprovedHomePage user={currentUser} onCreatePost={handleCreatePost} />;
    }
  };

  // Show dashboard if user is logged in and showDashboard is true
  if (currentUser) {
    return (
      <>
        <Toaster />
        <nav className="fixed top-0 w-full bg-white dark:bg-gray-900 backdrop-blur-sm border-b border-blue-100 dark:border-gray-700 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center">
                <button 
                  onClick={handleLogoClick}
                  className="text-xl text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors"
                >
                  Skill-Bridge
                </button>
              </div>
              <div className="flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleTheme}
                  className="text-gray-600 dark:text-gray-300"
                >
                  {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
                </Button>
                <span className="text-sm text-gray-600 dark:text-gray-300 hidden md:inline">
                  Welcome, {currentUser.fullName || currentUser.email}
                </span>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleLogout}
                  className="border-blue-600 text-blue-600 hover:bg-blue-50 dark:border-blue-400 dark:text-blue-400 dark:hover:bg-gray-800"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </div>
            </div>
          </div>
        </nav>

        <Sidebar
          activeTab={activeTab}
          onTabChange={handleTabChange}
          onLogout={handleLogout}
          isOpen={sidebarOpen}
          onToggle={() => setSidebarOpen(!sidebarOpen)}
        />

        <div className={`transition-all duration-300 ${sidebarOpen ? "lg:ml-64" : "ml-0"} pt-16`}>
          {renderContent()}
        </div>
      </>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Toaster />
      <SimpleAuthModal 
        open={authModalOpen} 
        onOpenChange={setAuthModalOpen} 
        onSuccess={handleAuthSuccess}
      />
      <SkillFormModal
        open={skillFormOpen}
        onOpenChange={setSkillFormOpen}
        user={currentUser || {}}
        onComplete={handleSkillFormComplete}
      />

      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm z-50 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-600 to-teal-500 flex items-center justify-center">
                <span className="text-white text-xl">S</span>
              </div>
              <h1 className="text-xl text-gray-900 dark:text-white">Skill Bridge</h1>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#how-it-works" className="text-gray-700 dark:text-gray-300 hover:text-blue-600 transition-colors">How It Works</a>
              <a href="#features" className="text-gray-700 dark:text-gray-300 hover:text-blue-600 transition-colors">Features</a>
              <a href="#jobs" className="text-gray-700 dark:text-gray-300 hover:text-blue-600 transition-colors">Categories</a>
            </div>
            {currentUser ? (
              <div className="flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleTheme}
                  className="text-gray-600 dark:text-gray-300"
                >
                  {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
                </Button>
                <span className="text-sm text-gray-600 dark:text-gray-300 hidden md:inline">
                  Welcome, {currentUser.fullName || currentUser.email}
                </span>
                <Button 
                  size="sm"
                  onClick={() => setShowDashboard(true)}
                  className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600"
                >
                  Dashboard
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleLogout}
                  className="border-blue-600 text-blue-600 hover:bg-blue-50 dark:border-blue-400 dark:text-blue-400 dark:hover:bg-gray-800"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <Button 
                  variant="outline"
                  onClick={() => setAuthModalOpen(true)}
                  className="border-blue-600 text-blue-600 hover:bg-blue-50 dark:border-blue-400 dark:text-blue-400"
                >
                  Sign In
                </Button>
                <Button 
                  className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600"
                  onClick={() => setAuthModalOpen(true)}
                >
                  Get Started
                </Button>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 pb-12">
          <div className="text-center max-w-4xl mx-auto">
            {/* Tagline */}
            <div className="inline-flex items-center gap-2 mb-6">
              <div className="w-2 h-2 rounded-full bg-green-500"></div>
              <span className="text-blue-600">Connecting Skills with Purpose</span>
            </div>

            {/* Main Heading */}
            <h1 className="text-5xl lg:text-6xl text-gray-900 dark:text-gray-100 mb-6">
              Bridge the Gap Between<br />
              <span className="bg-gradient-to-r from-blue-600 via-blue-500 to-teal-500 bg-clip-text text-transparent">
                Talent & Opportunity
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-12 max-w-3xl mx-auto">
              Connect skilled volunteers and freelancers with companies, NGOs, and 
              industries that need their expertise. Make an impact while building your 
              career.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-20">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600 shadow-lg px-8"
                onClick={() => setAuthModalOpen(true)}
              >
                Get Started Free
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-2 border-blue-600 text-blue-600 hover:bg-blue-50 dark:border-blue-400 dark:text-blue-400 px-8"
                onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Learn More
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
              <div className="text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Users className="h-6 w-6 text-blue-600" />
                  <span className="text-4xl text-blue-600">10K+</span>
                </div>
                <p className="text-gray-600 dark:text-gray-400">Active Volunteers</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Building2 className="h-6 w-6 text-teal-600" />
                  <span className="text-4xl text-teal-600">500+</span>
                </div>
                <p className="text-gray-600 dark:text-gray-400">Organizations</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Award className="h-6 w-6 text-yellow-600" />
                  <span className="text-4xl text-yellow-600">2K+</span>
                </div>
                <p className="text-gray-600 dark:text-gray-400">Successful Matches</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section id="about" className="py-16 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl text-gray-900 dark:text-gray-100 mb-4">About Skill-Bridge</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Empowering employment opportunities for skilled workers of all backgrounds, connecting talent with employers to reduce unemployment and build stronger communities.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-12">
            <div>
              <h3 className="text-2xl text-gray-900 dark:text-gray-100 mb-4">Our Mission</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                To eliminate unemployment barriers by connecting skilled workers directly with employers who need their talents. We believe every skill has value, whether learned in school, on the job, or through life experience.
              </p>
              <h3 className="text-2xl text-gray-900 dark:text-gray-100 mb-4">Our Vision</h3>
              <p className="text-gray-600 dark:text-gray-300">
                A world where employment opportunities are accessible to all skilled individuals, regardless of formal education, creating thriving communities where everyone can contribute their unique talents.
              </p>
            </div>
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1745448797901-2a4c9d9af1c1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxza2lsbGVkJTIwbWFudWFsJTIwd29ya2VycyUyMGNvbnN0cnVjdGlvbiUyMHRyYWRlc3xlbnwxfHx8fDE3NTc3MzcxNTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Skilled manual workers in construction and trades"
              className="rounded-xl shadow-lg w-1/2 h-[125px] object-cover mx-auto"
            />
          </div>

          {/* Team Section */}
          <div className="text-center mb-8">
            <h3 className="text-2xl text-gray-900 dark:text-gray-100 mb-6">Meet Our Team</h3>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
            <Card className="text-center border-blue-100">
              <CardHeader>
                <div className="w-20 h-20 bg-blue-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Users className="h-10 w-10 text-blue-600" />
                </div>
                <CardTitle className="text-lg">Mrs. Iswarya</CardTitle>
                <CardDescription>Project Mentor</CardDescription>
              </CardHeader>
            </Card>
            
            <Card className="text-center border-blue-100 bg-blue-50/50">
              <CardHeader>
                <div className="w-20 h-20 bg-blue-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Crown className="h-10 w-10 text-white" />
                </div>
                <CardTitle className="text-lg">Dhanush G</CardTitle>
                <CardDescription className="text-blue-600">Team Leader</CardDescription>
              </CardHeader>
            </Card>
            
            {["Ajay A", "Hariharan B", "Abishek K"].map((name, index) => (
              <Card key={index} className="text-center border-blue-100">
                <CardHeader>
                  <div className="w-20 h-20 bg-blue-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <UserCheck className="h-10 w-10 text-blue-600" />
                  </div>
                  <CardTitle className="text-lg">{name}</CardTitle>
                  <CardDescription>Team Member</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl text-gray-900 dark:text-gray-100 mb-4">
              How It <span className="text-blue-600">Works</span>
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Get started in minutes and begin making a difference today
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="bg-white dark:bg-gray-900 border-blue-100 hover:shadow-lg transition-all hover:-translate-y-1">
              <CardHeader className="text-center pb-4">
                <div className="relative mb-6">
                  <div className="w-16 h-16 bg-blue-600 rounded-full mx-auto flex items-center justify-center">
                    <UserCheck className="h-8 w-8 text-white" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto left-0 right-0">
                    <span className="text-blue-600 dark:text-blue-400">1</span>
                  </div>
                </div>
                <CardTitle className="text-xl mb-2">Create Your Profile</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 dark:text-gray-300">
                  Sign up and showcase your skills, experience, and what you're passionate about.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-white dark:bg-gray-900 border-blue-100 hover:shadow-lg transition-all hover:-translate-y-1">
              <CardHeader className="text-center pb-4">
                <div className="relative mb-6">
                  <div className="w-16 h-16 bg-blue-600 rounded-full mx-auto flex items-center justify-center">
                    <Target className="h-8 w-8 text-white" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto left-0 right-0">
                    <span className="text-blue-600 dark:text-blue-400">2</span>
                  </div>
                </div>
                <CardTitle className="text-xl mb-2">Discover Opportunities</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 dark:text-gray-300">
                  Browse through projects from NGOs, companies, and industries seeking your expertise.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-white dark:bg-gray-900 border-blue-100 hover:shadow-lg transition-all hover:-translate-y-1">
              <CardHeader className="text-center pb-4">
                <div className="relative mb-6">
                  <div className="w-16 h-16 bg-blue-600 rounded-full mx-auto flex items-center justify-center">
                    <Users className="h-8 w-8 text-white" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto left-0 right-0">
                    <span className="text-blue-600 dark:text-blue-400">3</span>
                  </div>
                </div>
                <CardTitle className="text-xl mb-2">Connect & Collaborate</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 dark:text-gray-300">
                  Get matched with organizations that align with your skills and values.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-white dark:bg-gray-900 border-blue-100 hover:shadow-lg transition-all hover:-translate-y-1">
              <CardHeader className="text-center pb-4">
                <div className="relative mb-6">
                  <div className="w-16 h-16 bg-blue-600 rounded-full mx-auto flex items-center justify-center">
                    <Lightbulb className="h-8 w-8 text-white" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto left-0 right-0">
                    <span className="text-blue-600 dark:text-blue-400">4</span>
                  </div>
                </div>
                <CardTitle className="text-xl mb-2">Make an Impact</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 dark:text-gray-300">
                  Contribute your skills while gaining experience and building meaningful connections.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Authentication Flow Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <AuthFlowDiagram />
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl text-gray-900 dark:text-gray-100 mb-4">Platform Features</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Everything you need to find employment or hire skilled workers
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="border-blue-100 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <Target className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>Skill-Based Matching</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center dark:text-gray-300">
                  Advanced matching connects workers with employers based on practical skills, location, and job requirements
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-blue-100 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <Shield className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>Skills Verification</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center dark:text-gray-300">
                  Workers can showcase their abilities through practical demonstrations and employer references
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-blue-100 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>Local Community</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center dark:text-gray-300">
                  Connect with local employers and workers in your area to build strong community relationships
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-blue-100 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <CheckCircle className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>Fair Employment</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center dark:text-gray-300">
                  Transparent job listings with fair wages and clear expectations for all skill levels
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Job Categories Section */}
      <section id="jobs" className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl text-gray-900 dark:text-gray-100 mb-4">Job Categories</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Find opportunities across diverse industries and skill levels
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            <Card className="bg-white border-blue-100 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <Hammer className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>Construction & Trades</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center mb-4 dark:text-gray-300">
                  Carpentry, plumbing, electrical work, masonry, roofing, and more skilled trades
                </p>
                <ul className="text-sm text-gray-500 space-y-1 dark:text-gray-400">
                  <li>• Carpenters</li>
                  <li>• Electricians</li>
                  <li>• Plumbers</li>
                  <li>• Masons</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="bg-white border-blue-100 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <Wrench className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>Technical Services</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center mb-4 dark:text-gray-300">
                  Repair, maintenance, automotive, and technical support services
                </p>
                <ul className="text-sm text-gray-500 space-y-1 dark:text-gray-400">
                  <li>• Auto Mechanics</li>
                  <li>• Appliance Repair</li>
                  <li>• IT Support</li>
                  <li>• Equipment Maintenance</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="bg-white border-blue-100 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <HandHeart className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>Service Industries</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center mb-4 dark:text-gray-300">
                  Hospitality, food service, cleaning, security, and personal services
                </p>
                <ul className="text-sm text-gray-500 space-y-1 dark:text-gray-400">
                  <li>• Cooks & Chefs</li>
                  <li>• Cleaners</li>
                  <li>• Security Guards</li>
                  <li>• Caregivers</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="bg-white border-blue-100 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <Briefcase className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>Professional Services</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center mb-4 dark:text-gray-300">
                  Business, administrative, creative, and professional support roles
                </p>
                <ul className="text-sm text-gray-500 space-y-1 dark:text-gray-400">
                  <li>• Administrative Assistants</li>
                  <li>• Graphic Designers</li>
                  <li>• Bookkeepers</li>
                  <li>• Consultants</li>
                </ul>
              </CardContent>
            </Card>
          </div>
          
          <div className="text-center">
            <p className="text-lg text-gray-600 dark:text-gray-300 mb-6">
              Don't see your skill listed? We welcome all types of work and expertise.
            </p>
            <Button 
              size="lg" 
              className="bg-blue-600 hover:bg-blue-700"
              onClick={() => openAuthModal()}
            >
              Post Your Skills
            </Button>
          </div>
        </div>
      </section>

      {/* Success Stories Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl text-gray-900 dark:text-gray-100 mb-4">Success Stories</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Real people finding real jobs through Skill-Bridge
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            <Card className="bg-white border-blue-100">
              <CardHeader>
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full mr-4"></div>
                  <div>
                    <CardTitle className="text-lg">Maria Santos</CardTitle>
                    <CardDescription>House Cleaner</CardDescription>
                  </div>
                </div>
                <div className="flex text-yellow-400 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300">
                  "I found steady cleaning work through Skill-Bridge without needing any certificates. Now I have regular clients and stable income for my family."
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-white border-blue-100">
              <CardHeader>
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full mr-4"></div>
                  <div>
                    <CardTitle className="text-lg">Robert Johnson</CardTitle>
                    <CardDescription>Carpenter</CardDescription>
                  </div>
                </div>
                <div className="flex text-yellow-400 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300">
                  "After being unemployed for months, Skill-Bridge helped me find construction projects that match my 20 years of carpentry experience."
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-white border-blue-100">
              <CardHeader>
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full mr-4"></div>
                  <div>
                    <CardTitle className="text-lg">Priya Patel</CardTitle>
                    <CardDescription>Home Cook & Catering</CardDescription>
                  </div>
                </div>
                <div className="flex text-yellow-400 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300">
                  "I turned my cooking skills into a business! Skill-Bridge connected me with families who needed meal preparation services."
                </p>
              </CardContent>
            </Card>
          </div>
          
          <div className="text-center">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div>
                <h3 className="text-3xl text-blue-600 mb-2">8,500+</h3>
                <p className="text-gray-600 dark:text-gray-300">Job Seekers</p>
              </div>
              <div>
                <h3 className="text-3xl text-blue-600 mb-2">2,100+</h3>
                <p className="text-gray-600 dark:text-gray-300">Employers</p>
              </div>
              <div>
                <h3 className="text-3xl text-blue-600 mb-2">12,000+</h3>
                <p className="text-gray-600 dark:text-gray-300">Jobs Filled</p>
              </div>
              <div>
                <h3 className="text-3xl text-blue-600 mb-2">94%</h3>
                <p className="text-gray-600 dark:text-gray-300">Employment Success Rate</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl text-gray-900 dark:text-gray-100 mb-4">Get Started Today</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Ready to find work or hire skilled workers? Let's get you started.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl text-gray-900 dark:text-gray-100 mb-6">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <Mail className="h-5 w-5 text-blue-600 mr-3" />
                  <span className="text-gray-600 dark:text-gray-300">skillbridge2025@gmail.com</span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-5 w-5 text-blue-600 mr-3" />
                  <span className="text-gray-600 dark:text-gray-300">9487654661</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 text-blue-600 mr-3" />
                  <span className="text-gray-600 dark:text-gray-300">SIET, chinniampalayam, coimbatore - 641062</span>
                </div>
              </div>
              
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1581374820531-029275791beb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBuZXR3b3JraW5nJTIwYnVzaW5lc3MlMjBtZWV0aW5nfGVufDF8fHx8MTc1NzcwNTcyMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Professional networking and business meeting"
                className="rounded-xl shadow-lg w-full h-[250px] object-cover mt-8"
              />
            </div>
            
            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle>Send us a message</CardTitle>
                <CardDescription>
                  We'd love to hear from you. Send us a message and we'll respond as soon as possible.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block mb-2">First Name</label>
                    <Input placeholder="John" />
                  </div>
                  <div>
                    <label className="block mb-2">Last Name</label>
                    <Input placeholder="Doe" />
                  </div>
                </div>
                <div>
                  <label className="block mb-2">Email</label>
                  <Input type="email" placeholder="john@example.com" />
                </div>
                <div>
                  <label className="block mb-2">Message</label>
                  <Textarea placeholder="Tell us how we can help you..." rows={4} />
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Send Message
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl mb-4">Skill-Bridge</h3>
              <p className="text-gray-400 mb-4">
                Connecting skilled workers with employment opportunities to reduce unemployment and build stronger communities.
              </p>
              <div className="flex space-x-4">
                <Facebook className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
                <Twitter className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
                <Linkedin className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
                <Instagram className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
              </div>
            </div>
            
            <div>
              <h4 className="mb-4">Platform</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Find Work</a></li>
                <li><a href="#" className="hover:text-white">Post Jobs</a></li>
                <li><a href="#" className="hover:text-white">How It Works</a></li>
                <li><a href="#" className="hover:text-white">Success Stories</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#about" className="hover:text-white">About</a></li>
                <li><a href="#features" className="hover:text-white">Features</a></li>
                <li><a href="#community" className="hover:text-white">Community</a></li>
                <li><a href="#contact" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white">Cookie Policy</a></li>
                <li><a href="#" className="hover:text-white">GDPR</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Skill-Bridge. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}