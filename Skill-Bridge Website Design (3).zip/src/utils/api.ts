import { projectId, publicAnonKey } from './supabase/info';
import { createClient } from '@supabase/supabase-js';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-2c3d544b`;

// Create Supabase client for frontend auth
export const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

// Helper function to make API calls
async function apiCall(endpoint: string, options: RequestInit = {}) {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
        ...options.headers,
      },
    });

    const data = await response.json();

    if (!response.ok) {
      console.error(`API Error - ${endpoint}:`, data.error || 'Unknown error');
      throw new Error(data.error || 'API request failed');
    }

    return data;
  } catch (error) {
    console.error(`API call failed for ${endpoint}:`, error);
    throw error;
  }
}

// ========== AUTH API ==========

export async function signUp(userData: {
  email: string;
  password: string;
  fullName: string;
  phone?: string;
  userType: 'worker' | 'employer';
  category?: string;
  address?: string;
  aadharNumber?: string;
}) {
  // First create auth user
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email: userData.email,
    password: userData.password,
  });

  if (authError) {
    throw new Error(authError.message);
  }

  // Then create user profile in backend
  return await apiCall('/signup', {
    method: 'POST',
    body: JSON.stringify(userData),
  });
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) {
    throw new Error(error.message);
  }

  return data;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) {
    throw new Error(error.message);
  }
}

export async function getCurrentSession() {
  const { data, error } = await supabase.auth.getSession();
  if (error) {
    throw new Error(error.message);
  }
  return data.session;
}

// ========== USER API ==========

export async function getUser(userId: string) {
  return await apiCall(`/user/${userId}`);
}

export async function updateUser(userId: string, updates: any) {
  return await apiCall(`/user/${userId}`, {
    method: 'PUT',
    body: JSON.stringify(updates),
  });
}

// ========== POSTS API ==========

export async function createPost(postData: {
  userId: string;
  postType: 'job' | 'general' | 'opportunity';
  content: string;
  title?: string;
  category?: string;
  salary?: string;
  location?: string;
  requirements?: string[];
}) {
  return await apiCall('/posts', {
    method: 'POST',
    body: JSON.stringify(postData),
  });
}

export async function getAllPosts() {
  return await apiCall('/posts');
}

export async function getUserPosts(userId: string) {
  return await apiCall(`/posts/user/${userId}`);
}

export async function likePost(postId: string, userId: string) {
  return await apiCall(`/posts/${postId}/like`, {
    method: 'POST',
    body: JSON.stringify({ userId }),
  });
}

// ========== MESSAGING API ==========

export async function getConversations(userId: string) {
  return await apiCall(`/conversations/${userId}`);
}

export async function sendMessage(messageData: {
  conversationId: string;
  senderId: string;
  content: string;
  type?: 'text' | 'image';
}) {
  return await apiCall('/messages', {
    method: 'POST',
    body: JSON.stringify(messageData),
  });
}

export async function getMessages(conversationId: string) {
  return await apiCall(`/messages/${conversationId}`);
}

// ========== CONTACT API ==========

export async function submitContactForm(formData: {
  name: string;
  email: string;
  subject?: string;
  message: string;
}) {
  return await apiCall('/contact', {
    method: 'POST',
    body: JSON.stringify(formData),
  });
}

// ========== APPLICATIONS API ==========

export async function applyForJob(applicationData: {
  jobPostId: string;
  applicantId: string;
  coverLetter?: string;
}) {
  return await apiCall('/applications', {
    method: 'POST',
    body: JSON.stringify(applicationData),
  });
}

export async function getJobApplications(jobPostId: string) {
  return await apiCall(`/applications/job/${jobPostId}`);
}

export async function getUserApplications(userId: string) {
  return await apiCall(`/applications/user/${userId}`);
}