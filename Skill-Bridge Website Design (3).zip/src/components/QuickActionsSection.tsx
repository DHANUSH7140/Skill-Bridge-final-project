import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Button } from "./ui/button";
import {
  Briefcase,
  Users,
  MessageSquare,
  Bell,
  Search,
  FileText,
  Download,
  Upload,
  Calendar,
  TrendingUp,
  Award,
  Share2,
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface QuickActionsSectionProps {
  user: any;
}

export function QuickActionsSection({ user }: QuickActionsSectionProps) {
  const isWorker = user.userType === "VOLUNTEER";
  const isEmployer = user.userType === "NGO" || user.userType === "CONSTRUCTION" || user.userType === "SERVICE_INDUSTRY";

  const handleAction = (action: string) => {
    toast.info(`${action} feature coming soon!`);
  };

  const workerActions = [
    {
      title: "Browse Jobs",
      description: "Find new job opportunities",
      icon: Briefcase,
      color: "bg-blue-100 text-blue-600",
      action: "browse-jobs",
    },
    {
      title: "Search Companies",
      description: "Discover employers",
      icon: Search,
      color: "bg-purple-100 text-purple-600",
      action: "search-companies",
    },
    {
      title: "View Applications",
      description: "Track your applications",
      icon: FileText,
      color: "bg-green-100 text-green-600",
      action: "view-applications",
    },
    {
      title: "Messages",
      description: "Chat with employers",
      icon: MessageSquare,
      color: "bg-orange-100 text-orange-600",
      action: "messages",
    },
    {
      title: "Notifications",
      description: "Check updates",
      icon: Bell,
      color: "bg-red-100 text-red-600",
      action: "notifications",
    },
    {
      title: "Schedule Interview",
      description: "Manage interviews",
      icon: Calendar,
      color: "bg-indigo-100 text-indigo-600",
      action: "schedule",
    },
    {
      title: "Download Resume",
      description: "Get your resume",
      icon: Download,
      color: "bg-teal-100 text-teal-600",
      action: "download-resume",
    },
    {
      title: "Skill Assessment",
      description: "Test your skills",
      icon: Award,
      color: "bg-yellow-100 text-yellow-600",
      action: "skill-test",
    },
  ];

  const employerActions = [
    {
      title: "Post a Job",
      description: "Create new job posting",
      icon: Briefcase,
      color: "bg-blue-100 text-blue-600",
      action: "post-job",
    },
    {
      title: "Browse Workers",
      description: "Find skilled workers",
      icon: Users,
      color: "bg-purple-100 text-purple-600",
      action: "browse-workers",
    },
    {
      title: "View Applications",
      description: "Review applicants",
      icon: FileText,
      color: "bg-green-100 text-green-600",
      action: "view-applications",
    },
    {
      title: "Messages",
      description: "Chat with candidates",
      icon: MessageSquare,
      color: "bg-orange-100 text-orange-600",
      action: "messages",
    },
    {
      title: "Notifications",
      description: "Check updates",
      icon: Bell,
      color: "bg-red-100 text-red-600",
      action: "notifications",
    },
    {
      title: "Schedule Interviews",
      description: "Manage interviews",
      icon: Calendar,
      color: "bg-indigo-100 text-indigo-600",
      action: "schedule",
    },
    {
      title: "Upload Job Data",
      description: "Bulk job upload",
      icon: Upload,
      color: "bg-teal-100 text-teal-600",
      action: "upload-data",
    },
    {
      title: "Analytics",
      description: "View hiring stats",
      icon: TrendingUp,
      color: "bg-yellow-100 text-yellow-600",
      action: "analytics",
    },
    {
      title: "Share Job Post",
      description: "Promote on social media",
      icon: Share2,
      color: "bg-pink-100 text-pink-600",
      action: "share",
    },
  ];

  const actions = isWorker ? workerActions : employerActions;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl text-gray-900 mb-2">Quick Actions</h1>
          <p className="text-gray-600">
            {isWorker
              ? "Access frequently used features to manage your job search"
              : "Manage your hiring process efficiently with these shortcuts"}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {actions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Card
                key={index}
                className="hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => handleAction(action.title)}
              >
                <CardHeader>
                  <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mb-4`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <CardTitle>{action.title}</CardTitle>
                  <CardDescription>{action.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" className="w-full">
                    Launch
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Recent Activity */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Your latest actions on the platform</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { action: "Applied to Senior Carpenter position", time: "2 hours ago" },
                { action: "Updated profile information", time: "1 day ago" },
                { action: "Messaged BuildRight Construction", time: "2 days ago" },
                { action: "Completed skill assessment", time: "3 days ago" },
              ].map((item, index) => (
                <div key={index} className="flex items-center justify-between py-2 border-b last:border-0">
                  <span className="text-gray-700">{item.action}</span>
                  <span className="text-sm text-gray-500">{item.time}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
