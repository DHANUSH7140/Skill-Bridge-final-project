import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Avatar } from "./ui/avatar";
import { Badge } from "./ui/badge";
import {
  Users,
  UserPlus,
  UserCheck,
  Search,
  Mail,
  MapPin,
  Building2,
  Hammer,
  Briefcase,
  MessageSquare,
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ConnectionsSectionProps {
  user: any;
}

export function ConnectionsSection({ user }: ConnectionsSectionProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeView, setActiveView] = useState<"all" | "my-connections">("all");
  const [connections, setConnections] = useState<string[]>([]);

  // Load connections from localStorage
  useEffect(() => {
    const storedConnections = localStorage.getItem(`connections_${user.userId}`);
    if (storedConnections) {
      setConnections(JSON.parse(storedConnections));
    }
  }, [user.userId]);

  // Mock users data - In production, this would come from the database
  const allUsers = [
    {
      id: "1",
      fullName: "Rajesh Kumar",
      category: "CONSTRUCTION",
      userType: "employer",
      location: "Mumbai",
      bio: "Construction company owner looking for skilled workers",
      skills: ["Project Management", "Safety Compliance"],
      companyName: "Kumar Constructions",
    },
    {
      id: "2",
      fullName: "Priya Sharma",
      category: "VOLUNTEER",
      userType: "worker",
      location: "Delhi",
      bio: "Passionate about connecting skilled workers with opportunities",
      skills: ["Community Outreach", "Training", "Coordination"],
    },
    {
      id: "3",
      fullName: "Amit Patel",
      category: "SERVICE_INDUSTRY",
      userType: "employer",
      location: "Bangalore",
      bio: "Hospitality services provider",
      skills: ["Customer Service", "Team Management"],
      companyName: "Patel Services Ltd",
    },
    {
      id: "4",
      fullName: "Sunita Reddy",
      category: "NGO",
      userType: "employer",
      location: "Hyderabad",
      bio: "Working to reduce unemployment through skill development",
      skills: ["Training Programs", "Job Placement"],
      organizationName: "Hope Foundation",
    },
    {
      id: "5",
      fullName: "Vikram Singh",
      category: "CONSTRUCTION",
      userType: "employer",
      location: "Pune",
      bio: "Building infrastructure for a better tomorrow",
      skills: ["Civil Engineering", "Project Planning"],
      companyName: "Singh Builders",
    },
    {
      id: "6",
      fullName: "Meera Iyer",
      category: "VOLUNTEER",
      userType: "worker",
      location: "Chennai",
      bio: "Volunteer coordinator helping communities grow",
      skills: ["Event Planning", "Communication", "Advocacy"],
    },
  ];

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "NGO":
        return Building2;
      case "CONSTRUCTION":
        return Hammer;
      case "SERVICE_INDUSTRY":
        return Briefcase;
      case "VOLUNTEER":
        return Users;
      default:
        return Users;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "NGO":
        return "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300";
      case "CONSTRUCTION":
        return "bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300";
      case "SERVICE_INDUSTRY":
        return "bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300";
      case "VOLUNTEER":
        return "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300";
      default:
        return "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300";
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "SERVICE_INDUSTRY":
        return "Service Professional";
      case "CONSTRUCTION":
        return "Construction";
      default:
        return category;
    }
  };

  const handleConnect = (userId: string) => {
    const updatedConnections = [...connections, userId];
    setConnections(updatedConnections);
    localStorage.setItem(`connections_${user.userId}`, JSON.stringify(updatedConnections));
    toast.success("Connection request sent!");
  };

  const handleDisconnect = (userId: string) => {
    const updatedConnections = connections.filter((id) => id !== userId);
    setConnections(updatedConnections);
    localStorage.setItem(`connections_${user.userId}`, JSON.stringify(updatedConnections));
    toast.success("Disconnected successfully");
  };

  const isConnected = (userId: string) => connections.includes(userId);

  const filteredUsers = allUsers
    .filter((u) => u.id !== user.userId) // Exclude current user
    .filter((u) => {
      if (activeView === "my-connections") {
        return isConnected(u.id);
      }
      return true;
    })
    .filter((u) => {
      if (!searchQuery) return true;
      const query = searchQuery.toLowerCase();
      return (
        u.fullName.toLowerCase().includes(query) ||
        u.category.toLowerCase().includes(query) ||
        u.location.toLowerCase().includes(query) ||
        u.bio.toLowerCase().includes(query)
      );
    });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl text-gray-900 dark:text-white mb-2">Connections</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Connect with other users to expand your network
          </p>
        </div>

        {/* Search and Filter */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Search by name, location, or category..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant={activeView === "all" ? "default" : "outline"}
                  onClick={() => setActiveView("all")}
                  className={activeView === "all" ? "bg-blue-600" : ""}
                >
                  <Users className="h-4 w-4 mr-2" />
                  All Users
                </Button>
                <Button
                  variant={activeView === "my-connections" ? "default" : "outline"}
                  onClick={() => setActiveView("my-connections")}
                  className={activeView === "my-connections" ? "bg-blue-600" : ""}
                >
                  <UserCheck className="h-4 w-4 mr-2" />
                  My Connections ({connections.length})
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Users Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredUsers.map((u) => {
            const CategoryIcon = getCategoryIcon(u.category);
            const connected = isConnected(u.id);

            return (
              <Card key={u.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-12 w-12 bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                        <span className="text-blue-600 dark:text-blue-300 text-lg">
                          {u.fullName.charAt(0)}
                        </span>
                      </Avatar>
                      <div>
                        <h3 className="text-gray-900 dark:text-white">{u.fullName}</h3>
                        <Badge className={getCategoryColor(u.category)}>
                          <CategoryIcon className="h-3 w-3 mr-1" />
                          {getCategoryLabel(u.category)}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {u.organizationName && (
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      <Building2 className="h-4 w-4 inline mr-1" />
                      {u.organizationName}
                    </p>
                  )}
                  {u.companyName && (
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      <Building2 className="h-4 w-4 inline mr-1" />
                      {u.companyName}
                    </p>
                  )}
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    <MapPin className="h-4 w-4 inline mr-1" />
                    {u.location}
                  </p>
                  <p className="text-sm text-gray-700 dark:text-gray-300">{u.bio}</p>
                  {u.skills && u.skills.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {u.skills.slice(0, 3).map((skill, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  )}
                  <div className="flex gap-2 pt-2">
                    {connected ? (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1"
                          onClick={() => handleDisconnect(u.id)}
                        >
                          <UserCheck className="h-4 w-4 mr-1" />
                          Connected
                        </Button>
                        <Button size="sm" variant="default" className="flex-1 bg-blue-600">
                          <MessageSquare className="h-4 w-4 mr-1" />
                          Message
                        </Button>
                      </>
                    ) : (
                      <Button
                        size="sm"
                        className="w-full bg-blue-600 hover:bg-blue-700"
                        onClick={() => handleConnect(u.id)}
                      >
                        <UserPlus className="h-4 w-4 mr-2" />
                        Connect
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredUsers.length === 0 && (
          <Card>
            <CardContent className="py-12 text-center">
              <Users className="h-16 w-16 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-600 dark:text-gray-400">
                {activeView === "my-connections"
                  ? "You don't have any connections yet. Start connecting with other users!"
                  : "No users found matching your search."}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
