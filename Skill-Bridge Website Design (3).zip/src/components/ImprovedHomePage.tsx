import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { JobRecommendations } from "./JobRecommendations";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import {
  Home,
  Briefcase,
  Users,
  TrendingUp,
  Award,
  MapPin,
  Clock,
  Target,
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ImprovedHomePageProps {
  user: any;
  onCreatePost: () => void;
}

export function ImprovedHomePage({ user, onCreatePost }: ImprovedHomePageProps) {
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [applicationDialogOpen, setApplicationDialogOpen] = useState(false);
  const [coverLetter, setCoverLetter] = useState("");

  const handleApply = (job: any) => {
    setSelectedJob(job);
    setApplicationDialogOpen(true);
  };

  const submitApplication = () => {
    if (!coverLetter.trim()) {
      toast.error("Please write a cover letter");
      return;
    }

    // Save application
    const applications = JSON.parse(localStorage.getItem(`applications_${user.userId}`) || "[]");
    applications.push({
      jobId: selectedJob.id,
      jobTitle: selectedJob.title,
      company: selectedJob.company,
      appliedDate: new Date().toISOString(),
      coverLetter,
      status: "pending",
    });
    localStorage.setItem(`applications_${user.userId}`, JSON.stringify(applications));

    toast.success("Application submitted successfully!");
    setApplicationDialogOpen(false);
    setCoverLetter("");
    setSelectedJob(null);
  };

  const stats = [
    {
      title: "Profile Views",
      value: "124",
      change: "+12%",
      icon: Users,
      color: "blue",
    },
    {
      title: "Applications",
      value: "8",
      change: "+3",
      icon: Briefcase,
      color: "green",
    },
    {
      title: "Skill Matches",
      value: "32",
      change: "+5",
      icon: Target,
      color: "purple",
    },
    {
      title: "Response Rate",
      value: "68%",
      change: "+8%",
      icon: TrendingUp,
      color: "orange",
    },
  ];

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-blue-900 dark:to-purple-900"></div>
        <div className="absolute inset-0 bg-pattern-dots"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-400/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8 relative z-10">
        {/* Welcome Header */}
        <div className="mb-8 animate-[slide-up_0.5s_ease-out]">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-4xl text-gray-900 dark:text-white mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Welcome back, {user.fullName}! 👋
              </h1>
              <p className="text-xl text-gray-600 dark:text-gray-400">
                Here's what's happening with your job search today
              </p>
            </div>
          </div>

          {/* Profile Completion Banner */}
          {!user.profileCompleted && (
            <Card className="border-orange-200 bg-orange-50 dark:bg-orange-900/20 dark:border-orange-800 mb-6">
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-gray-900 dark:text-white mb-1">
                      Complete your profile to unlock more opportunities
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Add your skills and experience to get better job matches
                    </p>
                  </div>
                  <Button className="bg-orange-600 hover:bg-orange-700">
                    Complete Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {stats.map((stat) => {
              const Icon = stat.icon;
              return (
                <Card key={stat.title} className="hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-2">
                      <div
                        className={`p-2 rounded-lg ${
                          stat.color === "blue"
                            ? "bg-blue-100 dark:bg-blue-900"
                            : stat.color === "green"
                            ? "bg-green-100 dark:bg-green-900"
                            : stat.color === "purple"
                            ? "bg-purple-100 dark:bg-purple-900"
                            : "bg-orange-100 dark:bg-orange-900"
                        }`}
                      >
                        <Icon
                          className={`h-5 w-5 ${
                            stat.color === "blue"
                              ? "text-blue-600 dark:text-blue-400"
                              : stat.color === "green"
                              ? "text-green-600 dark:text-green-400"
                              : stat.color === "purple"
                              ? "text-purple-600 dark:text-purple-400"
                              : "text-orange-600 dark:text-orange-400"
                          }`}
                        />
                      </div>
                      <Badge variant="outline" className="text-green-600">
                        {stat.change}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{stat.title}</p>
                    <p className="text-2xl text-gray-900 dark:text-white mt-1">{stat.value}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Profile Summary Card */}
        {user.profileCompleted && (
          <Card className="mb-8 bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0">
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="h-16 w-16 rounded-full bg-white/20 flex items-center justify-center text-2xl">
                      {user.fullName.charAt(0)}
                    </div>
                    <div>
                      <h2 className="text-2xl mb-1">{user.fullName}</h2>
                      <div className="flex items-center gap-3 text-blue-100">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {user.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {user.experience}
                        </span>
                        <span className="flex items-center gap-1">
                          <Award className="h-4 w-4" />
                          {user.skills?.length || 0} Skills
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {user.skills?.slice(0, 5).map((skill: string) => (
                      <Badge key={skill} className="bg-white/20 hover:bg-white/30 text-white border-white/30">
                        {skill}
                      </Badge>
                    ))}
                    {user.skills?.length > 5 && (
                      <Badge className="bg-white/20 text-white">
                        +{user.skills.length - 5} more
                      </Badge>
                    )}
                  </div>
                </div>
                <Button variant="outline" className="bg-white text-blue-600 hover:bg-blue-50">
                  Edit Profile
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Main Content Tabs */}
        <Tabs defaultValue="recommendations" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="recommendations">
              <TrendingUp className="h-4 w-4 mr-2" />
              For You
            </TabsTrigger>
            <TabsTrigger value="all-jobs">
              <Briefcase className="h-4 w-4 mr-2" />
              All Jobs
            </TabsTrigger>
            <TabsTrigger value="saved">
              <Home className="h-4 w-4 mr-2" />
              Saved
            </TabsTrigger>
          </TabsList>

          <TabsContent value="recommendations" className="space-y-6">
            <JobRecommendations user={user} onApply={handleApply} />
          </TabsContent>

          <TabsContent value="all-jobs">
            <Card>
              <CardContent className="py-12 text-center">
                <Briefcase className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-600 dark:text-gray-400">
                  Browse all available jobs coming soon...
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="saved">
            <Card>
              <CardContent className="py-12 text-center">
                <Home className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-600 dark:text-gray-400">
                  Your saved jobs will appear here
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Application Dialog */}
        <Dialog open={applicationDialogOpen} onOpenChange={setApplicationDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Apply for {selectedJob?.title}</DialogTitle>
              <DialogDescription>
                Please provide a cover letter to complete your application.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
                <CardContent className="pt-6">
                  <p className="text-sm text-gray-700 dark:text-gray-300">
                    <strong>Company:</strong> {selectedJob?.company}
                  </p>
                  <p className="text-sm text-gray-700 dark:text-gray-300">
                    <strong>Location:</strong> {selectedJob?.location}
                  </p>
                  <p className="text-sm text-gray-700 dark:text-gray-300">
                    <strong>Salary:</strong> {selectedJob?.salary}
                  </p>
                </CardContent>
              </Card>

              <div>
                <Label htmlFor="coverLetter">Cover Letter *</Label>
                <Textarea
                  id="coverLetter"
                  placeholder="Tell the employer why you're a great fit for this position..."
                  value={coverLetter}
                  onChange={(e) => setCoverLetter(e.target.value)}
                  rows={8}
                  className="mt-2"
                />
              </div>

              <div className="flex gap-2">
                <Button
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  onClick={submitApplication}
                >
                  Submit Application
                </Button>
                <Button variant="outline" onClick={() => setApplicationDialogOpen(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}