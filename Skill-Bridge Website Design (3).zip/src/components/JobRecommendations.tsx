import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import {
  Sparkles,
  MapPin,
  DollarSign,
  Clock,
  Briefcase,
  TrendingUp,
  Send,
  Bookmark,
  Share2,
  Building2,
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface JobRecommendationsProps {
  user: any;
  onApply: (job: any) => void;
}

export function JobRecommendations({ user, onApply }: JobRecommendationsProps) {
  const [savedJobs, setSavedJobs] = useState<string[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem(`saved_jobs_${user.userId}`);
    if (saved) {
      setSavedJobs(JSON.parse(saved));
    }
  }, [user.userId]);

  // Mock recommended jobs - in production, this would come from an AI matching algorithm
  const getRecommendedJobs = () => {
    const userSkills = user.skills || [];
    
    const allJobs = [
      {
        id: "job1",
        title: "Skilled Carpenter Needed",
        company: "Mumbai Constructions Ltd",
        location: "Mumbai, Maharashtra",
        salary: "₹25,000 - ₹35,000/month",
        type: "Full-time",
        description: "Looking for an experienced carpenter for residential projects. Must have 3+ years of experience.",
        requiredSkills: ["Carpentry", "Woodwork", "Furniture Making"],
        postedDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        applicants: 12,
        matchScore: 95,
      },
      {
        id: "job2",
        title: "Web Developer - Remote",
        company: "TechStart India",
        location: "Remote",
        salary: "₹40,000 - ₹60,000/month",
        type: "Contract",
        description: "Build and maintain responsive websites for small businesses. React and Node.js experience preferred.",
        requiredSkills: ["Web Development", "React", "JavaScript"],
        postedDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        applicants: 28,
        matchScore: 88,
      },
      {
        id: "job3",
        title: "Community Volunteer Coordinator",
        company: "Hope Foundation",
        location: "Delhi NCR",
        salary: "Stipend: ₹8,000/month",
        type: "Part-time",
        description: "Organize community events and coordinate volunteer activities for education programs.",
        requiredSkills: ["Community Service", "Event Planning", "Communication"],
        postedDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        applicants: 15,
        matchScore: 82,
      },
      {
        id: "job4",
        title: "Plumber for Residential Projects",
        company: "HomeFix Services",
        location: "Bangalore, Karnataka",
        salary: "₹20,000 - ₹30,000/month",
        type: "Full-time",
        description: "Handle plumbing installations and repairs for residential properties.",
        requiredSkills: ["Plumbing", "Pipe Fitting", "Maintenance"],
        postedDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        applicants: 8,
        matchScore: 78,
      },
      {
        id: "job5",
        title: "Graphic Designer - Freelance",
        company: "Creative Agency Pro",
        location: "Pune, Maharashtra",
        salary: "₹500 - ₹1,500/hour",
        type: "Freelance",
        description: "Create visual content for social media and marketing campaigns.",
        requiredSkills: ["Graphic Design", "Adobe Photoshop", "Creativity"],
        postedDate: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
        applicants: 22,
        matchScore: 75,
      },
      {
        id: "job6",
        title: "Teaching Assistant - Education NGO",
        company: "Educate India",
        location: "Hyderabad, Telangana",
        salary: "₹15,000 - ₹20,000/month",
        type: "Full-time",
        description: "Assist teachers in classroom activities and help underprivileged children with studies.",
        requiredSkills: ["Teaching", "Communication", "Patience"],
        postedDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        applicants: 18,
        matchScore: 72,
      },
    ];

    // Calculate match score based on user skills
    return allJobs
      .map((job) => {
        let matchScore = 0;
        const matchingSkills = job.requiredSkills.filter((skill) =>
          userSkills.some((userSkill: string) => 
            userSkill.toLowerCase().includes(skill.toLowerCase()) ||
            skill.toLowerCase().includes(userSkill.toLowerCase())
          )
        );
        matchScore = Math.round((matchingSkills.length / job.requiredSkills.length) * 100);
        
        return { ...job, matchScore, matchingSkills };
      })
      .filter((job) => job.matchScore > 0)
      .sort((a, b) => b.matchScore - a.matchScore);
  };

  const recommendedJobs = getRecommendedJobs();

  const toggleSaveJob = (jobId: string) => {
    const newSavedJobs = savedJobs.includes(jobId)
      ? savedJobs.filter((id) => id !== jobId)
      : [...savedJobs, jobId];
    
    setSavedJobs(newSavedJobs);
    localStorage.setItem(`saved_jobs_${user.userId}`, JSON.stringify(newSavedJobs));
    toast.success(savedJobs.includes(jobId) ? "Job removed from saved" : "Job saved!");
  };

  const getMatchColor = (score: number) => {
    if (score >= 80) return "text-green-600 dark:text-green-400";
    if (score >= 60) return "text-yellow-600 dark:text-yellow-400";
    return "text-orange-600 dark:text-orange-400";
  };

  const getMatchBadgeColor = (score: number) => {
    if (score >= 80) return "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300";
    if (score >= 60) return "bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300";
    return "bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300";
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    if (diff === 0) return "Today";
    if (diff === 1) return "Yesterday";
    return `${diff} days ago`;
  };

  if (recommendedJobs.length === 0) {
    return (
      <Card className="border-orange-200 bg-orange-50 dark:bg-orange-900/20 dark:border-orange-800">
        <CardContent className="py-12 text-center">
          <Sparkles className="h-16 w-16 mx-auto text-orange-400 mb-4" />
          <h3 className="text-xl text-gray-900 dark:text-white mb-2">
            No Recommendations Yet
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Complete your skill profile to get personalized job recommendations
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 shadow-lg">
            <Sparkles className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl text-gray-900 dark:text-white">
              Recommended for You
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              {recommendedJobs.length} jobs match your skills
            </p>
          </div>
        </div>
      </div>

      {/* Job Cards */}
      <div className="space-y-4">
        {recommendedJobs.map((job, index) => (
          <Card
            key={job.id}
            className="hover-lift border-l-4 backdrop-blur-sm bg-white/70 dark:bg-gray-800/70 animate-[slide-up_0.5s_ease-out]"
            style={{
              borderLeftColor: job.matchScore >= 80 ? "#10b981" : job.matchScore >= 60 ? "#f59e0b" : "#f97316",
              animationDelay: `${index * 0.1}s`
            }}
          >
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className={`${getMatchBadgeColor(job.matchScore)} shadow-sm`}>
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {job.matchScore}% Match
                    </Badge>
                    <Badge variant="outline" className="shadow-sm">{job.type}</Badge>
                  </div>
                  <CardTitle className="text-2xl mb-2 bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">{job.title}</CardTitle>
                  <div className="flex flex-wrap gap-3 text-sm text-gray-600 dark:text-gray-400">
                    <span className="flex items-center gap-1">
                      <Building2 className="h-4 w-4" />
                      {job.company}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      {job.location}
                    </span>
                    <span className="flex items-center gap-1">
                      <DollarSign className="h-4 w-4" />
                      {job.salary}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      Posted {formatDate(job.postedDate)}
                    </span>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleSaveJob(job.id)}
                  className={`${savedJobs.includes(job.id) ? "text-blue-600" : ""} hover:scale-110 transition-transform`}
                >
                  <Bookmark
                    className={`h-5 w-5 ${savedJobs.includes(job.id) ? "fill-current" : ""}`}
                  />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700 dark:text-gray-300">{job.description}</p>

              {/* Match Details */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    Skill Match
                  </span>
                  <span className={`text-sm ${getMatchColor(job.matchScore)}`}>
                    {job.matchingSkills?.length || 0} of {job.requiredSkills.length} skills
                  </span>
                </div>
                <Progress value={job.matchScore} className="h-2" />
              </div>

              {/* Skills */}
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                  Required Skills:
                </p>
                <div className="flex flex-wrap gap-2">
                  {job.requiredSkills.map((skill) => {
                    const isMatching = job.matchingSkills?.includes(skill);
                    return (
                      <Badge
                        key={skill}
                        className={`${
                          isMatching
                            ? "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300"
                            : "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300"
                        } shadow-sm`}
                      >
                        {skill}
                        {isMatching && " ✓"}
                      </Badge>
                    );
                  })}
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-4 border-t">
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  <Briefcase className="h-4 w-4 inline mr-1" />
                  {job.applicants} applicants
                </span>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="hover:scale-105 transition-transform">
                    <Share2 className="h-4 w-4 mr-1" />
                    Share
                  </Button>
                  <Button
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md hover:shadow-lg transition-all"
                    onClick={() => onApply(job)}
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Apply Now
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}