import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Avatar } from "./ui/avatar";
import {
  Users,
  MessageSquare,
  Search,
  Send,
  Plus,
  MoreVertical,
  Phone,
  Video,
  Paperclip,
  Smile,
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ChatSectionProps {
  user: any;
}

export function ChatSection({ user }: ChatSectionProps) {
  const [selectedChat, setSelectedChat] = useState<any>(null);
  const [message, setMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showCreateGroup, setShowCreateGroup] = useState(false);

  // Mock conversations
  const conversations = [
    {
      id: 1,
      name: "BuildRight Construction",
      type: "individual",
      avatar: "BC",
      lastMessage: "Thanks for applying! We'd like to schedule an interview.",
      time: "10:30 AM",
      unread: 2,
      online: true,
    },
    {
      id: 2,
      name: "Job Seekers Group",
      type: "group",
      avatar: "JSG",
      lastMessage: "Anyone know about openings in Coimbatore?",
      time: "Yesterday",
      unread: 0,
      online: false,
      members: 24,
    },
    {
      id: 3,
      name: "Priya Sharma",
      type: "individual",
      avatar: "PS",
      lastMessage: "Hi! I saw your profile and wanted to connect.",
      time: "2 days ago",
      unread: 1,
      online: false,
    },
    {
      id: 4,
      name: "Construction Workers United",
      type: "group",
      avatar: "CWU",
      lastMessage: "New project starting next week!",
      time: "3 days ago",
      unread: 0,
      online: false,
      members: 156,
    },
    {
      id: 5,
      name: "Rajesh Kumar",
      type: "individual",
      avatar: "RK",
      lastMessage: "Let me know if you need any references.",
      time: "1 week ago",
      unread: 0,
      online: true,
    },
  ];

  // Mock messages
  const messages = [
    {
      id: 1,
      sender: "BuildRight Construction",
      text: "Hello! We received your application for the Carpenter position.",
      time: "10:15 AM",
      isMe: false,
    },
    {
      id: 2,
      sender: "You",
      text: "Thank you! I'm very interested in this opportunity.",
      time: "10:20 AM",
      isMe: true,
    },
    {
      id: 3,
      sender: "BuildRight Construction",
      text: "Great! We'd like to schedule an interview for next Monday. Would 10 AM work for you?",
      time: "10:30 AM",
      isMe: false,
    },
  ];

  const handleSendMessage = () => {
    if (!message.trim()) return;
    toast.success("Message sent!");
    setMessage("");
  };

  const handleCreateGroup = () => {
    setShowCreateGroup(true);
    toast.info("Group creation feature coming soon!");
  };

  const filteredConversations = conversations.filter((conv) =>
    conv.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="h-[calc(100vh-4rem)] flex">
        {/* Conversations List */}
        <div className="w-full md:w-80 lg:w-96 bg-white border-r border-gray-200 flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl text-gray-900">Messages</h2>
              <Button
                size="sm"
                onClick={handleCreateGroup}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                New Group
              </Button>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Conversations List */}
          <div className="flex-1 overflow-y-auto">
            {filteredConversations.map((conv) => (
              <button
                key={conv.id}
                onClick={() => setSelectedChat(conv)}
                className={`w-full p-4 flex items-start gap-3 hover:bg-gray-50 transition-colors ${
                  selectedChat?.id === conv.id ? "bg-blue-50" : ""
                }`}
              >
                <div className="relative">
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      conv.type === "group" ? "bg-purple-100" : "bg-blue-100"
                    }`}
                  >
                    <span
                      className={`${
                        conv.type === "group" ? "text-purple-600" : "text-blue-600"
                      }`}
                    >
                      {conv.avatar}
                    </span>
                  </div>
                  {conv.online && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
                  )}
                </div>
                <div className="flex-1 text-left min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="text-gray-900 truncate">{conv.name}</h3>
                    <span className="text-xs text-gray-500">{conv.time}</span>
                  </div>
                  <p className="text-sm text-gray-500 truncate">{conv.lastMessage}</p>
                  {conv.type === "group" && (
                    <p className="text-xs text-gray-400 mt-1">{conv.members} members</p>
                  )}
                </div>
                {conv.unread > 0 && (
                  <div className="w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center">
                    <span className="text-xs text-white">{conv.unread}</span>
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          {selectedChat ? (
            <>
              {/* Chat Header */}
              <div className="p-4 bg-white border-b border-gray-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      selectedChat.type === "group" ? "bg-purple-100" : "bg-blue-100"
                    }`}
                  >
                    <span
                      className={`${
                        selectedChat.type === "group"
                          ? "text-purple-600"
                          : "text-blue-600"
                      }`}
                    >
                      {selectedChat.avatar}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-gray-900">{selectedChat.name}</h3>
                    <p className="text-sm text-gray-500">
                      {selectedChat.type === "group"
                        ? `${selectedChat.members} members`
                        : selectedChat.online
                        ? "Online"
                        : "Offline"}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm">
                    <Phone className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Video className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <MoreVertical className="h-5 w-5" />
                  </Button>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.isMe ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-md px-4 py-2 rounded-lg ${
                        msg.isMe
                          ? "bg-blue-600 text-white"
                          : "bg-white text-gray-900 border border-gray-200"
                      }`}
                    >
                      {!msg.isMe && (
                        <p className="text-xs text-gray-500 mb-1">{msg.sender}</p>
                      )}
                      <p>{msg.text}</p>
                      <p
                        className={`text-xs mt-1 ${
                          msg.isMe ? "text-blue-100" : "text-gray-500"
                        }`}
                      >
                        {msg.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Message Input */}
              <div className="p-4 bg-white border-t border-gray-200">
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm">
                    <Paperclip className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Smile className="h-5 w-5" />
                  </Button>
                  <Input
                    placeholder="Type a message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                    className="flex-1"
                  />
                  <Button
                    onClick={handleSendMessage}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center bg-gray-50">
              <div className="text-center">
                <MessageSquare className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl text-gray-600 mb-2">No Chat Selected</h3>
                <p className="text-gray-500">
                  Select a conversation to start messaging
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
