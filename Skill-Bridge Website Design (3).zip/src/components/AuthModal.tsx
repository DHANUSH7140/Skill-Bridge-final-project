import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Separator } from "./ui/separator";
import { Building2, Users, Hammer, Briefcase, ArrowLeft, Mail, Chrome, Github } from "lucide-react";
import { toast } from "sonner@2.0.3";
import { signUp, signIn, getUser } from "../utils/api";
import { projectId, publicAnonKey } from "../utils/supabase/info";

type UserType = "NGO" | "VOLUNTEER" | "CONSTRUCTION" | "SERVICE_INDUSTRY" | null;
type Mode = "selection" | "login" | "signup" | "verify2fa";

interface AuthModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialUserType?: UserType;
  mode?: "worker" | "employer" | "all";
  onSuccess?: () => void;
}

export function AuthModal({ open, onOpenChange, initialUserType = null, mode = "all", onSuccess }: AuthModalProps) {
  const [selectedUserType, setSelectedUserType] = useState<UserType>(initialUserType);
  const [authMode, setAuthMode] = useState<Mode>("selection");
  const [isLoading, setIsLoading] = useState(false);
  const [twoFAMethod, setTwoFAMethod] = useState<"email" | "phone">("email");
  const [verificationCode, setVerificationCode] = useState("");

  // Form states
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    fullName: "",
    organizationName: "",
    companyName: "",
    phone: "",
    address: "",
    aadharNumber: "",
    skills: "",
    experience: "",
    enable2FA: false,
  });

  const userTypes = [
    {
      type: "NGO" as UserType,
      title: "NGO",
      description: "Non-profit organizations connecting workers with opportunities",
      icon: Building2,
      category: "employer",
    },
    {
      type: "VOLUNTEER" as UserType,
      title: "Volunteer",
      description: "Individuals helping connect workers or coordinate programs",
      icon: Users,
      category: "worker",
    },
    {
      type: "CONSTRUCTION" as UserType,
      title: "Construction Worker",
      description: "Skilled workers in construction, trades, and manual labor",
      icon: Hammer,
      category: "employer",
    },
    {
      type: "SERVICE_INDUSTRY" as UserType,
      title: "Service Professional",
      description: "Workers in hospitality, professional services, and support roles",
      icon: Briefcase,
      category: "employer",
    },
  ];

  // Filter user types based on mode
  const filteredUserTypes = userTypes.filter((type) => {
    if (mode === "all") return true;
    return type.category === mode;
  });

  const handleUserTypeSelect = (type: UserType) => {
    setSelectedUserType(type);
    setAuthMode("login");
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSSOLogin = (provider: string) => {
    setIsLoading(true);
    toast.info(`Redirecting to ${provider} login...`);
    
    // Simulate SSO redirect
    setTimeout(() => {
      const userData = {
        email: `user@${provider.toLowerCase()}.com`,
        fullName: `${provider} User`,
        userType: selectedUserType,
        id: Math.random().toString(36).substr(2, 9),
        ssoProvider: provider,
      };

      localStorage.setItem("skillbridge_user", JSON.stringify(userData));
      toast.success(`Successfully logged in with ${provider}!`);
      setIsLoading(false);
      onOpenChange(false);
      resetForm();
      if (onSuccess) onSuccess();
    }, 2000);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const result = await signIn(formData.email, formData.password);
      
      if (result.session) {
        // Get user data from backend
        const { user: userData } = await getUser(result.user.id);
        
        const completeUserData = {
          ...userData,
          accessToken: result.session.access_token,
        };
        
        localStorage.setItem("skillbridge_user", JSON.stringify(completeUserData));
        toast.success(`Welcome back!`);
        setIsLoading(false);
        onOpenChange(false);
        resetForm();
        if (onSuccess) onSuccess();
      }
    } catch (error: any) {
      console.error("Login error:", error);
      toast.error(error.message || "Failed to login. Please check your credentials.");
      setIsLoading(false);
    }
  };

  const handleVerify2FA = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    setTimeout(() => {
      if (verificationCode.length === 6) {
        toast.success("2FA verification successful!");
        completeLogin();
      } else {
        toast.error("Invalid verification code");
        setIsLoading(false);
      }
    }, 1000);
  };

  const completeLogin = () => {
    const userData = {
      ...formData,
      userType: selectedUserType,
      id: Math.random().toString(36).substr(2, 9),
    };

    localStorage.setItem("skillbridge_user", JSON.stringify(userData));
    toast.success(`Welcome back! Logged in as ${selectedUserType}`);
    setIsLoading(false);
    onOpenChange(false);
    resetForm();
    if (onSuccess) onSuccess();
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Validate Aadhar number (basic validation - 12 digits)
    if (formData.aadharNumber.length !== 12) {
      toast.error("Aadhar number must be 12 digits");
      setIsLoading(false);
      return;
    }

    try {
      // Determine user type category
      const userTypeCategory = selectedUserType === 'VOLUNTEER' ? 'worker' : 'employer';
      
      const result = await signUp({
        email: formData.email,
        password: formData.password,
        fullName: formData.fullName,
        phone: formData.phone,
        userType: userTypeCategory,
        category: selectedUserType || '',
        address: formData.address,
        aadharNumber: formData.aadharNumber,
      });
      
      if (result.success) {
        // Auto-login after signup
        const loginResult = await signIn(formData.email, formData.password);
        
        if (loginResult.session) {
          const { user: userData } = await getUser(loginResult.user.id);
          
          const completeUserData = {
            ...userData,
            accessToken: loginResult.session.access_token,
          };
          
          localStorage.setItem("skillbridge_user", JSON.stringify(completeUserData));
          toast.success("Account created successfully! Welcome to Skill-Bridge");
          setIsLoading(false);
          onOpenChange(false);
          resetForm();
          if (onSuccess) onSuccess();
        }
      }
    } catch (error: any) {
      console.error("Signup error:", error);
      toast.error(error.message || "Failed to create account. Please try again.");
      setIsLoading(false);
    }
  };

  const completeSignup = () => {
    const userData = {
      ...formData,
      userType: selectedUserType,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString(),
    };

    localStorage.setItem("skillbridge_user", JSON.stringify(userData));
    toast.success(`Account created successfully! Welcome to Skill-Bridge`);
    setIsLoading(false);
    onOpenChange(false);
    resetForm();
    if (onSuccess) onSuccess();
  };

  const resetForm = () => {
    setFormData({
      email: "",
      password: "",
      fullName: "",
      organizationName: "",
      companyName: "",
      phone: "",
      address: "",
      aadharNumber: "",
      skills: "",
      experience: "",
      enable2FA: false,
    });
    setSelectedUserType(null);
    setAuthMode("selection");
    setVerificationCode("");
  };

  const handleBack = () => {
    if (authMode === "verify2fa") {
      setAuthMode("login");
      setVerificationCode("");
    } else if (authMode === "login" || authMode === "signup") {
      setAuthMode("selection");
      setSelectedUserType(null);
    }
  };

  const isVolunteer = selectedUserType === "VOLUNTEER";
  const isNGO = selectedUserType === "NGO";
  const isConstruction = selectedUserType === "CONSTRUCTION";
  const isServiceIndustry = selectedUserType === "SERVICE_INDUSTRY";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[550px] max-h-[90vh] overflow-y-auto">
        {authMode === "selection" ? (
          <>
            <DialogHeader>
              <DialogTitle>Choose Your Account Type</DialogTitle>
              <DialogDescription>
                Select the option that best describes you to get started
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              {filteredUserTypes.map((type) => {
                const Icon = type.icon;
                return (
                  <button
                    key={type.type}
                    onClick={() => handleUserTypeSelect(type.type)}
                    className="flex flex-col items-center p-6 border-2 border-blue-100 rounded-lg hover:border-blue-600 hover:bg-blue-50 transition-all cursor-pointer group"
                  >
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4 group-hover:bg-blue-600 transition-colors">
                      <Icon className="h-8 w-8 text-blue-600 group-hover:text-white transition-colors" />
                    </div>
                    <h3 className="text-gray-900 mb-2 text-center">{type.title}</h3>
                    <p className="text-sm text-gray-500 text-center">{type.description}</p>
                  </button>
                );
              })}
            </div>
          </>
        ) : authMode === "verify2fa" ? (
          <>
            <DialogHeader>
              <div className="flex items-center gap-2 mb-2">
                <Button variant="ghost" size="sm" onClick={handleBack}>
                  <ArrowLeft className="h-4 w-4" />
                </Button>
                <DialogTitle>Two-Factor Authentication</DialogTitle>
              </div>
              <DialogDescription>
                Enter the 6-digit code sent to your {twoFAMethod}
              </DialogDescription>
            </DialogHeader>

            <form onSubmit={handleVerify2FA} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="verificationCode">Verification Code *</Label>
                <Input
                  id="verificationCode"
                  type="text"
                  placeholder="Enter 6-digit code"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  required
                  maxLength={6}
                  className="text-center tracking-widest text-xl"
                />
              </div>

              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setTwoFAMethod(twoFAMethod === "email" ? "phone" : "email")}
                  className="text-sm"
                >
                  Send to {twoFAMethod === "email" ? "Phone" : "Email"}
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => toast.info("Code resent!")}
                  className="text-sm"
                >
                  Resend Code
                </Button>
              </div>

              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isLoading || verificationCode.length !== 6}>
                {isLoading ? "Verifying..." : "Verify & Continue"}
              </Button>
            </form>
          </>
        ) : (
          <>
            <DialogHeader>
              <div className="flex items-center gap-2 mb-2">
                <Button variant="ghost" size="sm" onClick={handleBack}>
                  <ArrowLeft className="h-4 w-4" />
                </Button>
                <DialogTitle>
                  {authMode === "login" ? "Login" : "Sign Up"} - {selectedUserType?.replace("_", " ")}
                </DialogTitle>
              </div>
              <DialogDescription>
                {authMode === "login"
                  ? "Enter your credentials to access your account"
                  : "Create your account to get started"}
              </DialogDescription>
            </DialogHeader>

            {/* SSO Options */}
            {authMode === "login" && (
              <div className="space-y-3 mt-4">
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => handleSSOLogin("Google")}
                  disabled={isLoading}
                >
                  <Chrome className="mr-2 h-4 w-4" />
                  Continue with Google
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => handleSSOLogin("GitHub")}
                  disabled={isLoading}
                >
                  <Github className="mr-2 h-4 w-4" />
                  Continue with GitHub
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => handleSSOLogin("Microsoft")}
                  disabled={isLoading}
                >
                  <Mail className="mr-2 h-4 w-4" />
                  Continue with Microsoft
                </Button>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <Separator />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-white px-2 text-gray-500">Or continue with email</span>
                  </div>
                </div>
              </div>
            )}

            <form onSubmit={authMode === "login" ? handleLogin : handleSignup} className="space-y-4 mt-4">
              {authMode === "signup" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name *</Label>
                    <Input
                      id="fullName"
                      type="text"
                      placeholder="Enter your full name"
                      value={formData.fullName}
                      onChange={(e) => handleInputChange("fullName", e.target.value)}
                      required
                    />
                  </div>

                  {/* NGO - Organization Name */}
                  {isNGO && (
                    <div className="space-y-2">
                      <Label htmlFor="organizationName">Organization Name *</Label>
                      <Input
                        id="organizationName"
                        type="text"
                        placeholder="Enter NGO organization name"
                        value={formData.organizationName}
                        onChange={(e) => handleInputChange("organizationName", e.target.value)}
                        required
                      />
                    </div>
                  )}

                  {/* Construction & Service Industry - Company Name */}
                  {(isConstruction || isServiceIndustry) && (
                    <div className="space-y-2">
                      <Label htmlFor="companyName">
                        {isConstruction ? "Construction Company Name *" : "Company Name *"}
                      </Label>
                      <Input
                        id="companyName"
                        type="text"
                        placeholder={isConstruction ? "Enter construction company name" : "Enter company name"}
                        value={formData.companyName}
                        onChange={(e) => handleInputChange("companyName", e.target.value)}
                        required
                      />
                    </div>
                  )}
                </>
              )}

              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={(e) => handleInputChange("password", e.target.value)}
                  required
                  minLength={6}
                />
              </div>

              {authMode === "signup" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+91 XXXXX XXXXX"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Address *</Label>
                    <Input
                      id="address"
                      type="text"
                      placeholder="Enter your complete address"
                      value={formData.address}
                      onChange={(e) => handleInputChange("address", e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="aadharNumber">Aadhar Number (Verification) *</Label>
                    <Input
                      id="aadharNumber"
                      type="text"
                      placeholder="XXXX XXXX XXXX"
                      value={formData.aadharNumber}
                      onChange={(e) => handleInputChange("aadharNumber", e.target.value.replace(/\D/g, "").slice(0, 12))}
                      required
                      maxLength={12}
                    />
                    <p className="text-xs text-gray-500">12-digit Aadhar number for identity verification</p>
                  </div>

                  {/* Volunteer - Skills & Experience */}
                  {isVolunteer && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="skills">Skills/Expertise *</Label>
                        <Input
                          id="skills"
                          type="text"
                          placeholder="e.g., Community Outreach, Coordination, Training"
                          value={formData.skills}
                          onChange={(e) => handleInputChange("skills", e.target.value)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="experience">Years of Experience</Label>
                        <Input
                          id="experience"
                          type="text"
                          placeholder="e.g., 3 years"
                          value={formData.experience}
                          onChange={(e) => handleInputChange("experience", e.target.value)}
                        />
                      </div>
                    </>
                  )}

                  {/* 2FA Option */}
                  <div className="flex items-center space-x-2 p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <input
                      type="checkbox"
                      id="enable2FA"
                      checked={formData.enable2FA}
                      onChange={(e) => handleInputChange("enable2FA", e.target.checked)}
                      className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <div className="flex-1">
                      <Label htmlFor="enable2FA" className="cursor-pointer">
                        Enable Two-Factor Authentication (Recommended)
                      </Label>
                      <p className="text-xs text-gray-600">Add extra security to your account</p>
                    </div>
                  </div>

                  {formData.enable2FA && (
                    <div className="space-y-2">
                      <Label>Receive verification codes via:</Label>
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant={twoFAMethod === "email" ? "default" : "outline"}
                          size="sm"
                          onClick={() => setTwoFAMethod("email")}
                          className={twoFAMethod === "email" ? "bg-blue-600" : ""}
                        >
                          <Mail className="mr-2 h-4 w-4" />
                          Email
                        </Button>
                        <Button
                          type="button"
                          variant={twoFAMethod === "phone" ? "default" : "outline"}
                          size="sm"
                          onClick={() => setTwoFAMethod("phone")}
                          className={twoFAMethod === "phone" ? "bg-blue-600" : ""}
                        >
                          Phone
                        </Button>
                      </div>
                    </div>
                  )}
                </>
              )}

              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isLoading}>
                {isLoading ? "Please wait..." : authMode === "login" ? "Login" : "Create Account"}
              </Button>

              <div className="text-center text-sm">
                {authMode === "login" ? (
                  <p className="text-gray-600">
                    Don't have an account?{" "}
                    <button
                      type="button"
                      onClick={() => setAuthMode("signup")}
                      className="text-blue-600 hover:underline"
                    >
                      Sign up
                    </button>
                  </p>
                ) : (
                  <p className="text-gray-600">
                    Already have an account?{" "}
                    <button
                      type="button"
                      onClick={() => setAuthMode("login")}
                      className="text-blue-600 hover:underline"
                    >
                      Login
                    </button>
                  </p>
                )}
              </div>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}