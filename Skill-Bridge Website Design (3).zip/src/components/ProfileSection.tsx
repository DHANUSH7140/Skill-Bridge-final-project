import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Users, Mail, Phone, MapPin, Briefcase, Edit2, Save } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ProfileSectionProps {
  user: any;
}

export function ProfileSection({ user }: ProfileSectionProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [profilePhoto, setProfilePhoto] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    fullName: user.fullName || "",
    email: user.email || "",
    phone: user.phone || "",
    address: user.address || "",
    skills: user.skills || "",
    experience: user.experience || "",
    bio: user.bio || "",
    organizationName: user.organizationName || "",
    companyName: user.companyName || "",
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handlePhotoUpload = () => {
    toast.info("Photo upload feature - Select from your device");
    // In a real app, this would open a file picker
    // For demo, we'll just show a success message
    setTimeout(() => {
      toast.success("Profile photo updated!");
    }, 500);
  };

  const handleSave = () => {
    // Update localStorage
    const updatedUser = { ...user, ...formData, profilePhoto };
    localStorage.setItem("skillbridge_user", JSON.stringify(updatedUser));
    
    toast.success("Profile updated successfully!");
    setIsEditing(false);
  };

  const isVolunteer = user.userType === "VOLUNTEER";
  const isNGO = user.userType === "NGO";
  const isConstruction = user.userType === "CONSTRUCTION";
  const isServiceIndustry = user.userType === "SERVICE_INDUSTRY";

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl text-gray-900 mb-2">My Profile</h1>
            <p className="text-gray-600">Manage your personal information and preferences</p>
          </div>
          <Button
            onClick={() => (isEditing ? handleSave() : setIsEditing(true))}
            className={isEditing ? "bg-green-600 hover:bg-green-700" : "bg-blue-600 hover:bg-blue-700"}
          >
            {isEditing ? (
              <>
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </>
            ) : (
              <>
                <Edit2 className="h-4 w-4 mr-2" />
                Edit Profile
              </>
            )}
          </Button>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Profile Picture Card */}
          <Card className="lg:col-span-1">
            <CardHeader className="text-center">
              <div className="w-32 h-32 bg-blue-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Users className="h-16 w-16 text-blue-600" />
              </div>
              <CardTitle>{formData.fullName}</CardTitle>
              <p className="text-sm text-gray-500">{user.userType.replace("_", " ")}</p>
            </CardHeader>
            <CardContent>
              {isEditing && (
                <Button variant="outline" className="w-full" onClick={handlePhotoUpload}>
                  Upload Photo
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Profile Information */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  {isEditing ? (
                    <Input
                      id="fullName"
                      value={formData.fullName}
                      onChange={(e) => handleInputChange("fullName", e.target.value)}
                    />
                  ) : (
                    <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                      <Users className="h-4 w-4 text-gray-500" />
                      <span className="text-gray-900">{formData.fullName}</span>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  {isEditing ? (
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                    />
                  ) : (
                    <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                      <Mail className="h-4 w-4 text-gray-500" />
                      <span className="text-gray-900">{formData.email}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  {isEditing ? (
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                    />
                  ) : (
                    <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                      <Phone className="h-4 w-4 text-gray-500" />
                      <span className="text-gray-900">{formData.phone}</span>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  {isEditing ? (
                    <Input
                      id="address"
                      value={formData.address}
                      onChange={(e) => handleInputChange("address", e.target.value)}
                    />
                  ) : (
                    <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                      <MapPin className="h-4 w-4 text-gray-500" />
                      <span className="text-gray-900">{formData.address}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Organization/Company Name */}
              {(isNGO || isConstruction || isServiceIndustry) && (
                <div className="space-y-2">
                  <Label htmlFor="organization">
                    {isNGO ? "Organization Name" : "Company Name"}
                  </Label>
                  {isEditing ? (
                    <Input
                      id="organization"
                      value={isNGO ? formData.organizationName : formData.companyName}
                      onChange={(e) =>
                        handleInputChange(
                          isNGO ? "organizationName" : "companyName",
                          e.target.value
                        )
                      }
                    />
                  ) : (
                    <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                      <Briefcase className="h-4 w-4 text-gray-500" />
                      <span className="text-gray-900">
                        {isNGO ? formData.organizationName : formData.companyName}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Skills and Experience for Volunteers */}
              {isVolunteer && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="skills">Skills</Label>
                    {isEditing ? (
                      <Input
                        id="skills"
                        value={formData.skills}
                        onChange={(e) => handleInputChange("skills", e.target.value)}
                      />
                    ) : (
                      <div className="p-2 bg-gray-50 rounded">
                        <span className="text-gray-900">{formData.skills}</span>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="experience">Experience</Label>
                    {isEditing ? (
                      <Input
                        id="experience"
                        value={formData.experience}
                        onChange={(e) => handleInputChange("experience", e.target.value)}
                      />
                    ) : (
                      <div className="p-2 bg-gray-50 rounded">
                        <span className="text-gray-900">{formData.experience}</span>
                      </div>
                    )}
                  </div>
                </>
              )}

              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                {isEditing ? (
                  <Textarea
                    id="bio"
                    value={formData.bio}
                    onChange={(e) => handleInputChange("bio", e.target.value)}
                    rows={4}
                    placeholder="Tell us about yourself..."
                  />
                ) : (
                  <div className="p-2 bg-gray-50 rounded min-h-[100px]">
                    <span className="text-gray-900">{formData.bio || "No bio added yet"}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Additional Cards */}
        <div className="grid lg:grid-cols-2 gap-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Account Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">User ID:</span>
                <span className="text-gray-900">{user.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Account Type:</span>
                <span className="text-gray-900">{user.userType.replace("_", " ")}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Member Since:</span>
                <span className="text-gray-900">
                  {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : "N/A"}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Verification Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Email Verified:</span>
                <span className="px-3 py-1 bg-green-100 text-green-700 text-sm rounded-full">
                  Verified
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Phone Verified:</span>
                <span className="px-3 py-1 bg-green-100 text-green-700 text-sm rounded-full">
                  Verified
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Aadhar Verified:</span>
                <span className="px-3 py-1 bg-green-100 text-green-700 text-sm rounded-full">
                  Verified
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}