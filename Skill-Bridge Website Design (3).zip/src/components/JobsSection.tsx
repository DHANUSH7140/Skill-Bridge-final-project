import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import {
  Briefcase,
  MapPin,
  DollarSign,
  Clock,
  Plus,
  Search,
  Filter,
  Building2,
  Send,
  CheckCircle,
  Eye,
  X,
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { getAllPosts, createPost, applyForJob, getUserApplications } from "../utils/api";

interface JobsSectionProps {
  user: any;
}

export function JobsSection({ user }: JobsSectionProps) {
  const [jobPosts, setJobPosts] = useState<any[]>([]);
  const [myApplications, setMyApplications] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [applicationDialogOpen, setApplicationDialogOpen] = useState(false);
  const [postJobDialogOpen, setPostJobDialogOpen] = useState(false);
  const [coverLetter, setCoverLetter] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [filterDialogOpen, setFilterDialogOpen] = useState(false);
  const [filters, setFilters] = useState({
    category: "all",
    location: "all",
    salaryRange: "all",
  });

  // Job posting form state
  const [jobForm, setJobForm] = useState({
    title: "",
    description: "",
    location: "",
    salary: "",
    requirements: "",
    experience: "",
    jobType: "Full-time",
  });

  const isVolunteer = user?.category === "VOLUNTEER";

  useEffect(() => {
    loadJobs();
    if (isVolunteer) {
      loadMyApplications();
    }
  }, []);

  const loadJobs = async () => {
    try {
      setIsLoading(true);
      const { posts } = await getAllPosts();
      // Filter only job posts
      const jobs = posts?.filter((post: any) => post.postType === "job") || [];
      setJobPosts(jobs);
    } catch (error) {
      console.error("Failed to load jobs:", error);
      toast.error("Failed to load jobs");
    } finally {
      setIsLoading(false);
    }
  };

  const loadMyApplications = async () => {
    try {
      const { applications } = await getUserApplications(user.userId);
      setMyApplications(applications || []);
    } catch (error) {
      console.error("Failed to load applications:", error);
    }
  };

  const handleJobFormChange = (field: string, value: string) => {
    setJobForm((prev) => ({ ...prev, [field]: value }));
  };

  const handlePostJob = async () => {
    if (!jobForm.title || !jobForm.description || !jobForm.location) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      setIsSubmitting(true);
      await createPost({
        userId: user.userId,
        postType: "job",
        title: jobForm.title,
        content: jobForm.description,
        location: jobForm.location,
        salary: jobForm.salary,
        requirements: jobForm.requirements ? [jobForm.requirements] : [],
        category: user.category || "",
      });

      toast.success("Job posted successfully!");
      setPostJobDialogOpen(false);
      setJobForm({
        title: "",
        description: "",
        location: "",
        salary: "",
        requirements: "",
        experience: "",
        jobType: "Full-time",
      });
      loadJobs();
    } catch (error: any) {
      console.error("Failed to post job:", error);
      toast.error(error.message || "Failed to post job");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleApplyForJob = async () => {
    if (!coverLetter.trim()) {
      toast.error("Please write a cover letter");
      return;
    }

    try {
      setIsSubmitting(true);
      await applyForJob({
        jobPostId: selectedJob.id,
        applicantId: user.userId,
        coverLetter,
      });

      toast.success("Application submitted successfully!");
      setApplicationDialogOpen(false);
      setCoverLetter("");
      setSelectedJob(null);
      loadMyApplications();
    } catch (error: any) {
      console.error("Failed to apply:", error);
      toast.error(error.message || "Failed to submit application");
    } finally {
      setIsSubmitting(false);
    }
  };

  const openApplicationDialog = (job: any) => {
    setSelectedJob(job);
    setApplicationDialogOpen(true);
  };

  const hasApplied = (jobId: string) => {
    return myApplications.some((app) => app.jobPostId === jobId);
  };

  const filteredJobs = jobPosts.filter((job) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      job.title?.toLowerCase().includes(query) ||
      job.content?.toLowerCase().includes(query) ||
      job.location?.toLowerCase().includes(query) ||
      job.category?.toLowerCase().includes(query)
    );
  });

  // Volunteer View - Job Application Section
  if (isVolunteer) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl text-gray-900 dark:text-white mb-2">Browse Jobs</h1>
            <p className="text-gray-600 dark:text-gray-400">
              Find and apply for volunteer opportunities
            </p>
          </div>

          {/* Search Bar */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input
                    placeholder="Search jobs by title, location, or category..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button variant="outline" onClick={() => setFilterDialogOpen(true)}>
                  <Filter className="h-4 w-4 mr-2" />
                  Filters
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* My Applications Summary */}
          {myApplications.length > 0 && (
            <Card className="mb-6 border-blue-200 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-800">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-900 dark:text-white mb-1">
                      You have {myApplications.length} active application
                      {myApplications.length !== 1 ? "s" : ""}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Track your applications and view their status
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    <Eye className="h-4 w-4 mr-2" />
                    View All
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Job Listings */}
          <div className="space-y-4">
            {isLoading ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-gray-600 dark:text-gray-400">Loading jobs...</p>
                </CardContent>
              </Card>
            ) : filteredJobs.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Briefcase className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">
                    No jobs found. Check back later for new opportunities!
                  </p>
                </CardContent>
              </Card>
            ) : (
              filteredJobs.map((job) => {
                const applied = hasApplied(job.id);
                return (
                  <Card key={job.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-xl mb-2">{job.title}</CardTitle>
                          <div className="flex flex-wrap gap-2 mb-3">
                            {job.author?.fullName && (
                              <Badge variant="outline">
                                <Building2 className="h-3 w-3 mr-1" />
                                {job.author.fullName}
                              </Badge>
                            )}
                            {job.location && (
                              <Badge variant="outline">
                                <MapPin className="h-3 w-3 mr-1" />
                                {job.location}
                              </Badge>
                            )}
                            {job.salary && (
                              <Badge variant="outline">
                                <DollarSign className="h-3 w-3 mr-1" />
                                {job.salary}
                              </Badge>
                            )}
                            <Badge variant="outline">
                              <Clock className="h-3 w-3 mr-1" />
                              Posted {new Date(job.createdAt).toLocaleDateString()}
                            </Badge>
                          </div>
                          <CardDescription className="text-base">
                            {job.content}
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {job.requirements && job.requirements.length > 0 && (
                        <div className="mb-4">
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                            Requirements:
                          </p>
                          <ul className="list-disc list-inside text-sm text-gray-700 dark:text-gray-300">
                            {job.requirements.map((req: string, idx: number) => (
                              <li key={idx}>{req}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                      <div className="flex gap-2">
                        {applied ? (
                          <Button
                            className="flex-1 bg-green-600 hover:bg-green-700"
                            disabled
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Applied
                          </Button>
                        ) : (
                          <Button
                            className="flex-1 bg-blue-600 hover:bg-blue-700"
                            onClick={() => openApplicationDialog(job)}
                          >
                            <Send className="h-4 w-4 mr-2" />
                            Apply Now
                          </Button>
                        )}
                        <Button variant="outline">View Details</Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>

          {/* Application Dialog */}
          <Dialog open={applicationDialogOpen} onOpenChange={setApplicationDialogOpen}>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Apply for {selectedJob?.title}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                    Tell the employer why you're a great fit for this position
                  </p>
                  <Label htmlFor="coverLetter">Cover Letter *</Label>
                  <Textarea
                    id="coverLetter"
                    placeholder="Write your cover letter here..."
                    value={coverLetter}
                    onChange={(e) => setCoverLetter(e.target.value)}
                    rows={8}
                    className="mt-2"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                    onClick={handleApplyForJob}
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Submitting..." : "Submit Application"}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setApplicationDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          {/* Filter Dialog */}
          <Dialog open={filterDialogOpen} onOpenChange={setFilterDialogOpen}>
            <DialogContent className="sm:max-w-[400px]">
              <DialogHeader>
                <DialogTitle>Filter Jobs</DialogTitle>
                <DialogDescription>
                  Refine your job search by category, location, and salary range
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Input
                    id="category"
                    placeholder="e.g., Volunteer, Internship"
                    value={filters.category}
                    onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    placeholder="e.g., Mumbai, Delhi"
                    value={filters.location}
                    onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="salaryRange">Salary Range</Label>
                  <Input
                    id="salaryRange"
                    placeholder="e.g., ₹30,000 - ₹40,000/month"
                    value={filters.salaryRange}
                    onChange={(e) => setFilters({ ...filters, salaryRange: e.target.value })}
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                    onClick={() => setFilterDialogOpen(false)}
                  >
                    Apply Filters
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setFilterDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    );
  }

  // Employer View - Job Posting Section
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl text-gray-900 dark:text-white mb-2">Job Postings</h1>
            <p className="text-gray-600 dark:text-gray-400">
              Manage your job postings and find skilled workers
            </p>
          </div>
          <Button
            className="bg-blue-600 hover:bg-blue-700"
            onClick={() => setPostJobDialogOpen(true)}
          >
            <Plus className="h-4 w-4 mr-2" />
            Post New Job
          </Button>
        </div>

        {/* Search Bar */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Search your job postings..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Job Listings */}
        <div className="space-y-4">
          {isLoading ? (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-gray-600 dark:text-gray-400">Loading jobs...</p>
              </CardContent>
            </Card>
          ) : filteredJobs.filter((job) => job.userId === user.userId).length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Briefcase className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  You haven't posted any jobs yet.
                </p>
                <Button
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={() => setPostJobDialogOpen(true)}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Post Your First Job
                </Button>
              </CardContent>
            </Card>
          ) : (
            filteredJobs
              .filter((job) => job.userId === user.userId)
              .map((job) => (
                <Card key={job.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-xl mb-2">{job.title}</CardTitle>
                        <div className="flex flex-wrap gap-2 mb-3">
                          {job.location && (
                            <Badge variant="outline">
                              <MapPin className="h-3 w-3 mr-1" />
                              {job.location}
                            </Badge>
                          )}
                          {job.salary && (
                            <Badge variant="outline">
                              <DollarSign className="h-3 w-3 mr-1" />
                              {job.salary}
                            </Badge>
                          )}
                          <Badge variant="outline">
                            <Clock className="h-3 w-3 mr-1" />
                            Posted {new Date(job.createdAt).toLocaleDateString()}
                          </Badge>
                          <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300">
                            {job.likes || 0} interested
                          </Badge>
                        </div>
                        <CardDescription className="text-base">
                          {job.content}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {job.requirements && job.requirements.length > 0 && (
                      <div className="mb-4">
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                          Requirements:
                        </p>
                        <ul className="list-disc list-inside text-sm text-gray-700 dark:text-gray-300">
                          {job.requirements.map((req: string, idx: number) => (
                            <li key={idx}>{req}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    <div className="flex gap-2">
                      <Button variant="outline" className="flex-1">
                        <Eye className="h-4 w-4 mr-2" />
                        View Applications (0)
                      </Button>
                      <Button variant="outline">Edit</Button>
                      <Button variant="outline" className="text-red-600 hover:text-red-700">
                        Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
          )}
        </div>

        {/* Post Job Dialog */}
        <Dialog open={postJobDialogOpen} onOpenChange={setPostJobDialogOpen}>
          <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Post a New Job</DialogTitle>
              <DialogDescription>
                Fill in the details to create a new job posting
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div>
                <Label htmlFor="jobTitle">Job Title *</Label>
                <Input
                  id="jobTitle"
                  placeholder="e.g., Senior Carpenter, Service Manager"
                  value={jobForm.title}
                  onChange={(e) => handleJobFormChange("title", e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="jobDescription">Job Description *</Label>
                <Textarea
                  id="jobDescription"
                  placeholder="Describe the job responsibilities and what you're looking for..."
                  value={jobForm.description}
                  onChange={(e) => handleJobFormChange("description", e.target.value)}
                  rows={5}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="location">Location *</Label>
                  <Input
                    id="location"
                    placeholder="e.g., Mumbai, Delhi"
                    value={jobForm.location}
                    onChange={(e) => handleJobFormChange("location", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="salary">Salary Range</Label>
                  <Input
                    id="salary"
                    placeholder="e.g., ₹30,000 - ₹40,000/month"
                    value={jobForm.salary}
                    onChange={(e) => handleJobFormChange("salary", e.target.value)}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="requirements">Requirements</Label>
                <Textarea
                  id="requirements"
                  placeholder="List the skills and qualifications required..."
                  value={jobForm.requirements}
                  onChange={(e) => handleJobFormChange("requirements", e.target.value)}
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                <Button
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  onClick={handlePostJob}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Posting..." : "Post Job"}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setPostJobDialogOpen(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}