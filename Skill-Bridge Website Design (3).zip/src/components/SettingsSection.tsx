import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";
import {
  Bell,
  Lock,
  Eye,
  Shield,
  Globe,
  Mail,
  Phone,
  Trash2,
  Download,
  AlertTriangle,
} from "lucide-react";
import { toast } from "sonner@2.0.3";

export function SettingsSection() {
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    sms: false,
    jobAlerts: true,
    messages: true,
    updates: false,
  });

  const [privacy, setPrivacy] = useState({
    profileVisible: true,
    showEmail: false,
    showPhone: false,
  });

  const handleNotificationChange = (key: string) => {
    setNotifications((prev) => ({ ...prev, [key]: !prev[key as keyof typeof prev] }));
    toast.success("Notification settings updated");
  };

  const handlePrivacyChange = (key: string) => {
    setPrivacy((prev) => ({ ...prev, [key]: !prev[key as keyof typeof prev] }));
    toast.success("Privacy settings updated");
  };

  const handlePasswordChange = () => {
    toast.success("Password change email sent to your inbox");
  };

  const handleDownloadData = () => {
    toast.info("Preparing your data for download...");
  };

  const handleDeleteAccount = () => {
    toast.error("Please contact support to delete your account");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl text-gray-900 mb-2">Settings</h1>
          <p className="text-gray-600">Manage your account settings and preferences</p>
        </div>

        <div className="space-y-6">
          {/* Notifications Settings */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-blue-600" />
                <CardTitle>Notification Preferences</CardTitle>
              </div>
              <CardDescription>Choose how you want to be notified</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-900">Email Notifications</p>
                  <p className="text-sm text-gray-500">Receive updates via email</p>
                </div>
                <Switch
                  checked={notifications.email}
                  onCheckedChange={() => handleNotificationChange("email")}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-900">Push Notifications</p>
                  <p className="text-sm text-gray-500">Get browser notifications</p>
                </div>
                <Switch
                  checked={notifications.push}
                  onCheckedChange={() => handleNotificationChange("push")}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-900">SMS Notifications</p>
                  <p className="text-sm text-gray-500">Receive text messages</p>
                </div>
                <Switch
                  checked={notifications.sms}
                  onCheckedChange={() => handleNotificationChange("sms")}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-900">Job Alerts</p>
                  <p className="text-sm text-gray-500">Get notified about new jobs</p>
                </div>
                <Switch
                  checked={notifications.jobAlerts}
                  onCheckedChange={() => handleNotificationChange("jobAlerts")}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-900">Message Notifications</p>
                  <p className="text-sm text-gray-500">Alerts for new messages</p>
                </div>
                <Switch
                  checked={notifications.messages}
                  onCheckedChange={() => handleNotificationChange("messages")}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-900">Platform Updates</p>
                  <p className="text-sm text-gray-500">News and feature announcements</p>
                </div>
                <Switch
                  checked={notifications.updates}
                  onCheckedChange={() => handleNotificationChange("updates")}
                />
              </div>
            </CardContent>
          </Card>

          {/* Privacy Settings */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Eye className="h-5 w-5 text-blue-600" />
                <CardTitle>Privacy Settings</CardTitle>
              </div>
              <CardDescription>Control your profile visibility</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-900">Public Profile</p>
                  <p className="text-sm text-gray-500">Make your profile visible to everyone</p>
                </div>
                <Switch
                  checked={privacy.profileVisible}
                  onCheckedChange={() => handlePrivacyChange("profileVisible")}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-900">Show Email</p>
                  <p className="text-sm text-gray-500">Display email on your profile</p>
                </div>
                <Switch
                  checked={privacy.showEmail}
                  onCheckedChange={() => handlePrivacyChange("showEmail")}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-900">Show Phone</p>
                  <p className="text-sm text-gray-500">Display phone number on your profile</p>
                </div>
                <Switch
                  checked={privacy.showPhone}
                  onCheckedChange={() => handlePrivacyChange("showPhone")}
                />
              </div>
            </CardContent>
          </Card>

          {/* Security Settings */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-blue-600" />
                <CardTitle>Security</CardTitle>
              </div>
              <CardDescription>Manage your account security</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="current-password">Change Password</Label>
                <div className="flex gap-2 mt-2">
                  <Input id="current-password" type="password" placeholder="Current Password" />
                  <Input type="password" placeholder="New Password" />
                </div>
                <Button onClick={handlePasswordChange} className="mt-2 bg-blue-600 hover:bg-blue-700">
                  <Lock className="h-4 w-4 mr-2" />
                  Update Password
                </Button>
              </div>

              <div className="pt-4 border-t">
                <h4 className="text-gray-900 mb-2">Two-Factor Authentication</h4>
                <p className="text-sm text-gray-500 mb-3">
                  Add an extra layer of security to your account
                </p>
                <Button variant="outline">
                  Enable 2FA
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Language & Region */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-blue-600" />
                <CardTitle>Language & Region</CardTitle>
              </div>
              <CardDescription>Set your language and location preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="language">Language</Label>
                <select
                  id="language"
                  className="w-full mt-2 p-2 border border-gray-300 rounded-lg"
                  defaultValue="en"
                >
                  <option value="en">English</option>
                  <option value="hi">Hindi</option>
                  <option value="ta">Tamil</option>
                  <option value="te">Telugu</option>
                </select>
              </div>

              <div>
                <Label htmlFor="timezone">Timezone</Label>
                <select
                  id="timezone"
                  className="w-full mt-2 p-2 border border-gray-300 rounded-lg"
                  defaultValue="ist"
                >
                  <option value="ist">India Standard Time (IST)</option>
                  <option value="utc">UTC</option>
                </select>
              </div>
            </CardContent>
          </Card>

          {/* Data & Privacy */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Download className="h-5 w-5 text-blue-600" />
                <CardTitle>Data & Privacy</CardTitle>
              </div>
              <CardDescription>Manage your personal data</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button variant="outline" onClick={handleDownloadData} className="w-full">
                <Download className="h-4 w-4 mr-2" />
                Download Your Data
              </Button>

              <p className="text-sm text-gray-500">
                Download a copy of your information from Skill-Bridge
              </p>
            </CardContent>
          </Card>

          {/* Danger Zone */}
          <Card className="border-red-200">
            <CardHeader>
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-red-600" />
                <CardTitle className="text-red-600">Danger Zone</CardTitle>
              </div>
              <CardDescription>Irreversible actions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="text-gray-900 mb-2">Delete Account</h4>
                <p className="text-sm text-gray-500 mb-3">
                  Once you delete your account, there is no going back. Please be certain.
                </p>
                <Button
                  variant="outline"
                  onClick={handleDeleteAccount}
                  className="border-red-600 text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete My Account
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
