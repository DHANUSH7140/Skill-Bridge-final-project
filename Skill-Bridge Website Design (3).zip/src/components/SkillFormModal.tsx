import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { Card, CardContent } from "./ui/card";
import { X, Plus, MapPin, Briefcase, Award, Target } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface SkillFormModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: any;
  onComplete?: (skillData: any) => void;
}

export function SkillFormModal({ open, onOpenChange, user, onComplete }: SkillFormModalProps) {
  const [skills, setSkills] = useState<string[]>([]);
  const [currentSkill, setCurrentSkill] = useState("");
  const [formData, setFormData] = useState({
    location: "",
    experience: "",
    bio: "",
    hourlyRate: "",
    availability: "full-time",
    portfolio: "",
  });

  // Suggested skills based on user type
  const suggestedSkills = user?.userType === "freelancer" ? [
    "Carpentry", "Plumbing", "Electrical Work", "Painting", "Welding",
    "Masonry", "Tailoring", "Cooking", "Cleaning", "Gardening",
    "Web Development", "Graphic Design", "Content Writing", "Photography",
    "Video Editing", "Digital Marketing", "Data Entry", "Virtual Assistant"
  ] : user?.userType === "volunteer" ? [
    "Teaching", "Community Service", "Event Planning", "Social Work",
    "Fundraising", "Youth Mentoring", "Environmental Conservation",
    "Healthcare Support", "Animal Welfare", "Food Distribution"
  ] : [
    "Project Management", "Recruitment", "Training & Development",
    "Community Outreach", "Grant Writing", "Program Coordination"
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const addSkill = (skill: string) => {
    if (skill && !skills.includes(skill)) {
      setSkills([...skills, skill]);
      setCurrentSkill("");
    }
  };

  const removeSkill = (skillToRemove: string) => {
    setSkills(skills.filter((s) => s !== skillToRemove));
  };

  const handleSubmit = () => {
    if (skills.length === 0) {
      toast.error("Please add at least one skill");
      return;
    }

    if (!formData.location || !formData.experience || !formData.bio) {
      toast.error("Please fill in all required fields");
      return;
    }

    const skillData = {
      ...formData,
      skills,
      profileCompleted: true,
      needsSkillForm: false,
    };

    // Update user data in localStorage
    const updatedUser = {
      ...user,
      ...skillData,
    };

    localStorage.setItem("skillbridge_user", JSON.stringify(updatedUser));
    localStorage.setItem(`user_${user.email}`, JSON.stringify(updatedUser));

    toast.success("Profile completed successfully!");
    if (onComplete) {
      onComplete(updatedUser);
    }
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Complete Your Profile</DialogTitle>
          <DialogDescription>
            Tell us about your skills and experience to get personalized job recommendations
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 mt-6">
          {/* Skills Section */}
          <div>
            <Label className="text-base mb-3 block">
              <Award className="h-4 w-4 inline mr-2" />
              Your Skills *
            </Label>
            <div className="space-y-3">
              <div className="flex gap-2">
                <Input
                  placeholder="Type a skill and press Enter"
                  value={currentSkill}
                  onChange={(e) => setCurrentSkill(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addSkill(currentSkill);
                    }
                  }}
                />
                <Button
                  type="button"
                  onClick={() => addSkill(currentSkill)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>

              {/* Display added skills */}
              {skills.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {skills.map((skill) => (
                    <Badge key={skill} className="bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300 px-3 py-1">
                      {skill}
                      <button
                        onClick={() => removeSkill(skill)}
                        className="ml-2 hover:text-red-600"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}

              {/* Suggested skills */}
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                  Suggested skills (click to add):
                </p>
                <div className="flex flex-wrap gap-2">
                  {suggestedSkills
                    .filter((s) => !skills.includes(s))
                    .slice(0, 10)
                    .map((skill) => (
                      <Badge
                        key={skill}
                        variant="outline"
                        className="cursor-pointer hover:bg-blue-50 dark:hover:bg-blue-900/20"
                        onClick={() => addSkill(skill)}
                      >
                        + {skill}
                      </Badge>
                    ))}
                </div>
              </div>
            </div>
          </div>

          {/* Location */}
          <div>
            <Label htmlFor="location">
              <MapPin className="h-4 w-4 inline mr-2" />
              Location *
            </Label>
            <Input
              id="location"
              placeholder="e.g., Mumbai, Maharashtra"
              value={formData.location}
              onChange={(e) => handleInputChange("location", e.target.value)}
            />
          </div>

          {/* Experience */}
          <div>
            <Label htmlFor="experience">
              <Briefcase className="h-4 w-4 inline mr-2" />
              Years of Experience *
            </Label>
            <Input
              id="experience"
              placeholder="e.g., 5 years"
              value={formData.experience}
              onChange={(e) => handleInputChange("experience", e.target.value)}
            />
          </div>

          {/* Bio */}
          <div>
            <Label htmlFor="bio">
              <Target className="h-4 w-4 inline mr-2" />
              About You *
            </Label>
            <Textarea
              id="bio"
              placeholder="Tell us about your experience, what you're looking for, and what makes you unique..."
              value={formData.bio}
              onChange={(e) => handleInputChange("bio", e.target.value)}
              rows={4}
            />
          </div>

          {/* Additional fields for freelancers */}
          {user?.userType === "freelancer" && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="hourlyRate">Hourly Rate (₹)</Label>
                  <Input
                    id="hourlyRate"
                    placeholder="e.g., 500"
                    value={formData.hourlyRate}
                    onChange={(e) => handleInputChange("hourlyRate", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="availability">Availability</Label>
                  <select
                    id="availability"
                    className="w-full h-10 rounded-md border border-gray-300 dark:border-gray-700 px-3 bg-white dark:bg-gray-800"
                    value={formData.availability}
                    onChange={(e) => handleInputChange("availability", e.target.value)}
                  >
                    <option value="full-time">Full Time</option>
                    <option value="part-time">Part Time</option>
                    <option value="contract">Contract</option>
                    <option value="freelance">Freelance</option>
                  </select>
                </div>
              </div>

              <div>
                <Label htmlFor="portfolio">Portfolio/Website (Optional)</Label>
                <Input
                  id="portfolio"
                  placeholder="https://yourportfolio.com"
                  value={formData.portfolio}
                  onChange={(e) => handleInputChange("portfolio", e.target.value)}
                />
              </div>
            </>
          )}

          {/* Info Card */}
          <Card className="border-blue-200 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-800">
            <CardContent className="pt-6">
              <p className="text-sm text-gray-700 dark:text-gray-300">
                💡 <strong>Tip:</strong> The more detailed your profile, the better job matches you'll receive!
                Add all your skills and provide a comprehensive description.
              </p>
            </CardContent>
          </Card>

          {/* Submit Button */}
          <div className="flex gap-3">
            <Button
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              onClick={handleSubmit}
            >
              Complete Profile & Continue
            </Button>
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Skip for Now
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}