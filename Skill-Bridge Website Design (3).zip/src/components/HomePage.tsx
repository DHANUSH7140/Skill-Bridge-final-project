import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Input } from "./ui/input";
import { Avatar } from "./ui/avatar";
import {
  Briefcase,
  MessageSquare,
  Heart,
  Share2,
  Image as ImageIcon,
  Video,
  FileText,
  TrendingUp,
  Users,
  MapPin,
  Clock,
  DollarSign,
  Plus,
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { getAllPosts, likePost } from "../utils/api";

interface HomePageProps {
  user: any;
  onCreatePost: () => void;
}

export function HomePage({ user, onCreatePost }: HomePageProps) {
  const [feedPosts, setFeedPosts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load posts from database
  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    try {
      setIsLoading(true);
      const { posts } = await getAllPosts();
      setFeedPosts(posts || []);
    } catch (error) {
      console.error("Failed to load posts:", error);
      toast.error("Failed to load posts");
    } finally {
      setIsLoading(false);
    }
  };

  const handleLike = async (postId: string) => {
    try {
      const result = await likePost(postId, user.userId);
      
      // Update local state
      setFeedPosts(prevPosts =>
        prevPosts.map(post =>
          post.id === postId
            ? { ...post, likes: result.likes, userLiked: result.liked }
            : post
        )
      );
      
      toast.success(result.liked ? "Post liked!" : "Post unliked");
    } catch (error) {
      console.error("Failed to like post:", error);
      toast.error("Failed to like post");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Floating Action Button */}
      <button
        onClick={onCreatePost}
        className="fixed bottom-8 right-8 w-14 h-14 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-lg flex items-center justify-center transition-all hover:scale-110 z-40"
      >
        <Plus className="h-6 w-6" />
      </button>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - User Info */}
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader className="text-center">
                <div className="w-20 h-20 bg-blue-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Users className="h-10 w-10 text-blue-600" />
                </div>
                <CardTitle>{user.fullName}</CardTitle>
                <CardDescription>{user.userType.replace("_", " ")}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Connections</span>
                  <span className="text-blue-600">324</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Posts</span>
                  <span className="text-blue-600">48</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Profile Views</span>
                  <span className="text-blue-600">1,234</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Trending Topics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {["#SkillDevelopment", "#HiringNow", "#ConstructionJobs", "#Volunteering"].map((tag) => (
                  <div key={tag} className="flex items-center justify-between">
                    <span className="text-blue-600">{tag}</span>
                    <TrendingUp className="h-4 w-4 text-gray-400" />
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Middle Column - Feed */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Create Post Card */}
            <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={onCreatePost}>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="flex-1 bg-gray-100 rounded-full px-4 py-2 text-gray-500 hover:bg-gray-200 transition-colors">
                    What's on your mind, {user.fullName}?
                  </div>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4 mr-2" />
                    Post
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Feed Posts */}
            {feedPosts.map((post) => (
              <Card key={post.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Users className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="text-gray-900">{post.author}</h3>
                        <p className="text-sm text-gray-500">
                          {post.userType.replace("_", " ")} • {post.time}
                        </p>
                      </div>
                    </div>
                    {post.type === "job" && (
                      <span className="px-3 py-1 bg-green-100 text-green-700 text-sm rounded-full">
                        Job Posting
                      </span>
                    )}
                    {post.type === "news" && (
                      <span className="px-3 py-1 bg-blue-100 text-blue-700 text-sm rounded-full">
                        News
                      </span>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {post.title && <h3 className="text-xl text-gray-900">{post.title}</h3>}
                  <p className="text-gray-700">{post.content}</p>

                  {post.type === "job" && (
                    <div className="flex flex-wrap gap-4 text-sm text-gray-600 bg-gray-50 p-4 rounded-lg">
                      {post.location && (
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {post.location}
                        </div>
                      )}
                      {post.salary && (
                        <div className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4" />
                          {post.salary}
                        </div>
                      )}
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="flex gap-4">
                      <button className="flex items-center gap-2 text-gray-600 hover:text-blue-600">
                        <Heart className="h-5 w-5" />
                        <span>{post.likes}</span>
                      </button>
                      <button className="flex items-center gap-2 text-gray-600 hover:text-blue-600">
                        <MessageSquare className="h-5 w-5" />
                        <span>{post.comments}</span>
                      </button>
                      <button className="flex items-center gap-2 text-gray-600 hover:text-blue-600">
                        <Share2 className="h-5 w-5" />
                        Share
                      </button>
                    </div>
                    {post.type === "job" && (
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                        Apply Now
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}