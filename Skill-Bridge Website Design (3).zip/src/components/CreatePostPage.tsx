import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Briefcase,
  MessageSquare,
  FileText,
  Image as ImageIcon,
  Video,
  MapPin,
  DollarSign,
  Calendar,
  X,
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { createPost } from "../utils/api";

interface CreatePostPageProps {
  user: any;
  onBack: () => void;
}

export function CreatePostPage({ user, onBack }: CreatePostPageProps) {
  const [postContent, setPostContent] = useState("");
  const [postType, setPostType] = useState<"general" | "job" | "news">("general");
  const [jobDetails, setJobDetails] = useState({
    title: "",
    location: "",
    salary: "",
    experience: "",
  });
  const [newsTitle, setNewsTitle] = useState("");
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [isPosting, setIsPosting] = useState(false);

  const handlePost = async () => {
    if (!postContent.trim()) {
      toast.error("Please write something to post");
      return;
    }

    if (postType === "job" && !jobDetails.title.trim()) {
      toast.error("Please enter job title");
      return;
    }

    if (postType === "news" && !newsTitle.trim()) {
      toast.error("Please enter news title");
      return;
    }

    try {
      setIsPosting(true);
      
      const postData: any = {
        userId: user.userId,
        postType: postType === "news" ? "general" : postType,
        content: postContent,
      };

      if (postType === "job") {
        postData.title = jobDetails.title;
        postData.location = jobDetails.location;
        postData.salary = jobDetails.salary;
        postData.requirements = jobDetails.experience ? [jobDetails.experience] : [];
        postData.category = user.category || '';
      } else if (postType === "news") {
        postData.title = newsTitle;
      }

      await createPost(postData);
      
      toast.success("Post published successfully!");
      onBack();
    } catch (error: any) {
      console.error("Failed to create post:", error);
      toast.error(error.message || "Failed to publish post. Please try again.");
    } finally {
      setIsPosting(false);
    }
  };

  const handleImageUpload = () => {
    toast.info("Image upload feature coming soon!");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl text-gray-900 mb-2">Create New Post</h1>
            <p className="text-gray-600">Share your updates with the community</p>
          </div>
          <Button variant="outline" onClick={onBack}>
            <X className="h-4 w-4 mr-2" />
            Cancel
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Post Type</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Post Type Selection */}
            <div className="flex gap-3">
              <Button
                size="lg"
                variant={postType === "general" ? "default" : "outline"}
                onClick={() => setPostType("general")}
                className={postType === "general" ? "bg-blue-600" : ""}
              >
                <MessageSquare className="h-5 w-5 mr-2" />
                General
              </Button>
              <Button
                size="lg"
                variant={postType === "job" ? "default" : "outline"}
                onClick={() => setPostType("job")}
                className={postType === "job" ? "bg-blue-600" : ""}
              >
                <Briefcase className="h-5 w-5 mr-2" />
                Job Posting
              </Button>
              <Button
                size="lg"
                variant={postType === "news" ? "default" : "outline"}
                onClick={() => setPostType("news")}
                className={postType === "news" ? "bg-blue-600" : ""}
              >
                <FileText className="h-5 w-5 mr-2" />
                News/Announcement
              </Button>
            </div>

            {/* Job Posting Fields */}
            {postType === "job" && (
              <div className="space-y-4 p-4 bg-blue-50 rounded-lg">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="jobTitle">Job Title *</Label>
                    <Input
                      id="jobTitle"
                      placeholder="e.g. Senior Carpenter"
                      value={jobDetails.title}
                      onChange={(e) =>
                        setJobDetails({ ...jobDetails, title: e.target.value })
                      }
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      placeholder="e.g. Coimbatore"
                      value={jobDetails.location}
                      onChange={(e) =>
                        setJobDetails({ ...jobDetails, location: e.target.value })
                      }
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="salary">Salary Range</Label>
                    <Input
                      id="salary"
                      placeholder="e.g. ₹25,000 - ₹35,000/month"
                      value={jobDetails.salary}
                      onChange={(e) =>
                        setJobDetails({ ...jobDetails, salary: e.target.value })
                      }
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="experience">Experience Required</Label>
                    <Input
                      id="experience"
                      placeholder="e.g. 3-5 years"
                      value={jobDetails.experience}
                      onChange={(e) =>
                        setJobDetails({ ...jobDetails, experience: e.target.value })
                      }
                      className="mt-1"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* News Title Field */}
            {postType === "news" && (
              <div className="p-4 bg-blue-50 rounded-lg">
                <Label htmlFor="newsTitle">News/Announcement Title *</Label>
                <Input
                  id="newsTitle"
                  placeholder="Enter a catchy headline"
                  value={newsTitle}
                  onChange={(e) => setNewsTitle(e.target.value)}
                  className="mt-1"
                />
              </div>
            )}

            {/* Post Content */}
            <div>
              <Label htmlFor="content">
                {postType === "job"
                  ? "Job Description *"
                  : postType === "news"
                  ? "Full Content *"
                  : "What's on your mind? *"}
              </Label>
              <Textarea
                id="content"
                placeholder={
                  postType === "job"
                    ? "Describe the role, responsibilities, and requirements..."
                    : postType === "news"
                    ? "Write the full announcement or news..."
                    : "Share your thoughts, updates, or achievements..."
                }
                value={postContent}
                onChange={(e) => setPostContent(e.target.value)}
                rows={8}
                className="mt-1"
              />
              <p className="text-sm text-gray-500 mt-2">
                {postContent.length} characters
              </p>
            </div>

            {/* Media Upload Options */}
            <div>
              <Label>Add Media</Label>
              <div className="flex gap-2 mt-2">
                <Button variant="outline" onClick={handleImageUpload}>
                  <ImageIcon className="h-4 w-4 mr-2" />
                  Add Photos
                </Button>
                <Button variant="outline" onClick={() => toast.info("Video upload coming soon!")}>
                  <Video className="h-4 w-4 mr-2" />
                  Add Video
                </Button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={onBack}>
                Cancel
              </Button>
              <Button onClick={handlePost} className="bg-blue-600 hover:bg-blue-700">
                Publish Post
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}