import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Building2, Users, Hammer, Briefcase, ArrowRight, UserCheck, Lightbulb } from "lucide-react";

export function AuthFlowDiagram() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl text-gray-900 mb-4">Authentication Flow</h2>
        <p className="text-xl text-gray-600">Four user types, seamless registration</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8 mb-12">
        {/* Workers Flow */}
        <Card className="border-blue-200">
          <CardHeader className="bg-blue-50">
            <CardTitle className="flex items-center gap-2">
              <Hammer className="h-5 w-5 text-blue-600" />
              Workers Flow
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  1
                </div>
                <div>
                  <h4 className="text-gray-900 mb-1">Click "Find Work"</h4>
                  <p className="text-sm text-gray-600">Choose between Construction or Service Industry worker type</p>
                </div>
              </div>

              <div className="flex items-center justify-center">
                <ArrowRight className="h-5 w-5 text-gray-400" />
              </div>

              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  2
                </div>
                <div>
                  <h4 className="text-gray-900 mb-1">Sign Up / Login</h4>
                  <p className="text-sm text-gray-600">Enter details: name, email, password, phone, skills, experience</p>
                </div>
              </div>

              <div className="flex items-center justify-center">
                <ArrowRight className="h-5 w-5 text-gray-400" />
              </div>

              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <UserCheck className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <h4 className="text-gray-900 mb-1">Access Dashboard</h4>
                  <p className="text-sm text-gray-600">Browse jobs, apply, track applications, manage profile</p>
                </div>
              </div>

              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <h5 className="text-sm text-gray-900 mb-2">User Types:</h5>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Hammer className="h-4 w-4 text-blue-600" />
                    <span className="text-gray-600">Construction Worker</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Briefcase className="h-4 w-4 text-blue-600" />
                    <span className="text-gray-600">Service Industry Professional</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Employers Flow */}
        <Card className="border-green-200">
          <CardHeader className="bg-green-50">
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-green-600" />
              Employers Flow
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  1
                </div>
                <div>
                  <h4 className="text-gray-900 mb-1">Click "Hire Skilled Workers"</h4>
                  <p className="text-sm text-gray-600">Choose between NGO or Volunteer organization type</p>
                </div>
              </div>

              <div className="flex items-center justify-center">
                <ArrowRight className="h-5 w-5 text-gray-400" />
              </div>

              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  2
                </div>
                <div>
                  <h4 className="text-gray-900 mb-1">Sign Up / Login</h4>
                  <p className="text-sm text-gray-600">Enter details: name, organization, email, password, phone</p>
                </div>
              </div>

              <div className="flex items-center justify-center">
                <ArrowRight className="h-5 w-5 text-gray-400" />
              </div>

              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <Lightbulb className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-gray-900 mb-1">Access Dashboard</h4>
                  <p className="text-sm text-gray-600">Post jobs, review applicants, manage hiring process</p>
                </div>
              </div>

              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <h5 className="text-sm text-gray-900 mb-2">User Types:</h5>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Building2 className="h-4 w-4 text-green-600" />
                    <span className="text-gray-600">NGO Organization</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="h-4 w-4 text-green-600" />
                    <span className="text-gray-600">Volunteer Coordinator</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Get Started Flow */}
      <Card className="border-purple-200">
        <CardHeader className="bg-purple-50">
          <CardTitle className="flex items-center gap-2">
            <UserCheck className="h-5 w-5 text-purple-600" />
            "Get Started" - All User Types
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid md:grid-cols-4 gap-4">
            <div className="text-center p-4 border border-gray-200 rounded-lg hover:border-blue-600 transition-colors">
              <Building2 className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <h4 className="text-sm text-gray-900 mb-1">NGO</h4>
              <p className="text-xs text-gray-500">Organizations helping workers</p>
            </div>

            <div className="text-center p-4 border border-gray-200 rounded-lg hover:border-blue-600 transition-colors">
              <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <h4 className="text-sm text-gray-900 mb-1">Volunteer</h4>
              <p className="text-xs text-gray-500">Program coordinators</p>
            </div>

            <div className="text-center p-4 border border-gray-200 rounded-lg hover:border-blue-600 transition-colors">
              <Hammer className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <h4 className="text-sm text-gray-900 mb-1">Construction</h4>
              <p className="text-xs text-gray-500">Skilled trade workers</p>
            </div>

            <div className="text-center p-4 border border-gray-200 rounded-lg hover:border-blue-600 transition-colors">
              <Briefcase className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <h4 className="text-sm text-gray-900 mb-1">Service Industry</h4>
              <p className="text-xs text-gray-500">Professional services</p>
            </div>
          </div>

          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600 text-center">
              <strong>Note:</strong> "Get Started" button shows all 4 user type options. Users select their type, then proceed with signup/login specific to their category.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
