import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Card, CardContent } from "./ui/card";
import { Briefcase, Users, Wrench } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface SimpleAuthModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: (userData: any) => void;
}

export function SimpleAuthModal({ open, onOpenChange, onSuccess }: SimpleAuthModalProps) {
  const [authTab, setAuthTab] = useState<"login" | "register">("login");
  const [selectedUserType, setSelectedUserType] = useState<"freelancer" | "volunteer" | "ngo" | null>(null);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    fullName: "",
    phone: "",
  });

  const userTypes = [
    {
      id: "freelancer",
      title: "Freelancer / Skilled Worker",
      description: "Find work opportunities based on your skills",
      icon: Wrench,
      color: "blue",
    },
    {
      id: "volunteer",
      title: "Volunteer",
      description: "Help communities while gaining experience",
      icon: Users,
      color: "green",
    },
    {
      id: "ngo",
      title: "NGO / Employer",
      description: "Post jobs and find skilled workers",
      icon: Briefcase,
      color: "purple",
    },
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleLogin = () => {
    if (!formData.email || !formData.password) {
      toast.error("Please fill in all fields");
      return;
    }

    // Check localStorage for existing user
    const storedUser = localStorage.getItem(`user_${formData.email}`);
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      if (userData.password === formData.password) {
        localStorage.setItem("skillbridge_user", JSON.stringify(userData));
        toast.success("Login successful!");
        onSuccess(userData);
        onOpenChange(false);
      } else {
        toast.error("Invalid credentials");
      }
    } else {
      toast.error("User not found. Please register first.");
    }
  };

  const handleRegister = () => {
    if (!selectedUserType) {
      toast.error("Please select your user type");
      return;
    }

    if (!formData.email || !formData.password || !formData.fullName || !formData.phone) {
      toast.error("Please fill in all fields");
      return;
    }

    // Check if user already exists
    const existingUser = localStorage.getItem(`user_${formData.email}`);
    if (existingUser) {
      toast.error("User already exists. Please login.");
      return;
    }

    const userData = {
      userId: `user_${Date.now()}`,
      email: formData.email,
      password: formData.password,
      fullName: formData.fullName,
      phone: formData.phone,
      userType: selectedUserType,
      needsSkillForm: true,
      createdAt: new Date().toISOString(),
    };

    // Save user
    localStorage.setItem(`user_${formData.email}`, JSON.stringify(userData));
    localStorage.setItem("skillbridge_user", JSON.stringify(userData));
    
    toast.success("Registration successful! Please complete your skill profile.");
    onSuccess(userData);
    onOpenChange(false);
  };

  const resetForm = () => {
    setFormData({ email: "", password: "", fullName: "", phone: "" });
    setSelectedUserType(null);
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => {
      onOpenChange(isOpen);
      if (!isOpen) resetForm();
    }}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl text-center">Welcome to Skill-Bridge</DialogTitle>
          <DialogDescription className="text-sm text-center text-gray-600 dark:text-gray-400">
            Connect with skilled workers and employers
          </DialogDescription>
        </DialogHeader>

        <Tabs value={authTab} onValueChange={(v) => setAuthTab(v as "login" | "register")}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Register</TabsTrigger>
          </TabsList>

          <TabsContent value="login" className="space-y-4 mt-6">
            <div>
              <Label htmlFor="login-email">Email</Label>
              <Input
                id="login-email"
                type="email"
                placeholder="your.email@example.com"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="login-password">Password</Label>
              <Input
                id="login-password"
                type="password"
                placeholder="Enter your password"
                value={formData.password}
                onChange={(e) => handleInputChange("password", e.target.value)}
              />
            </div>
            <Button
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={handleLogin}
            >
              Login
            </Button>
            <p className="text-sm text-center text-gray-600 dark:text-gray-400">
              Don't have an account?{" "}
              <button
                onClick={() => setAuthTab("register")}
                className="text-blue-600 hover:underline"
              >
                Register here
              </button>
            </p>
          </TabsContent>

          <TabsContent value="register" className="space-y-4 mt-6">
            {/* User Type Selection */}
            <div>
              <Label className="mb-3 block">I am a...</Label>
              <div className="grid grid-cols-1 gap-3">
                {userTypes.map((type) => {
                  const Icon = type.icon;
                  const isSelected = selectedUserType === type.id;
                  return (
                    <Card
                      key={type.id}
                      className={`cursor-pointer transition-all ${
                        isSelected
                          ? "border-blue-600 bg-blue-50 dark:bg-blue-900/20"
                          : "hover:border-gray-400"
                      }`}
                      onClick={() => setSelectedUserType(type.id as any)}
                    >
                      <CardContent className="p-4 flex items-start gap-3">
                        <div className={`p-2 rounded-lg ${
                          type.color === "blue" ? "bg-blue-100 dark:bg-blue-900" :
                          type.color === "green" ? "bg-green-100 dark:bg-green-900" :
                          "bg-purple-100 dark:bg-purple-900"
                        }`}>
                          <Icon className={`h-5 w-5 ${
                            type.color === "blue" ? "text-blue-600 dark:text-blue-400" :
                            type.color === "green" ? "text-green-600 dark:text-green-400" :
                            "text-purple-600 dark:text-purple-400"
                          }`} />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-gray-900 dark:text-white mb-1">
                            {type.title}
                          </h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {type.description}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* Registration Form */}
            <div>
              <Label htmlFor="register-name">Full Name</Label>
              <Input
                id="register-name"
                placeholder="Your full name"
                value={formData.fullName}
                onChange={(e) => handleInputChange("fullName", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="register-email">Email</Label>
              <Input
                id="register-email"
                type="email"
                placeholder="your.email@example.com"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="register-phone">Phone Number</Label>
              <Input
                id="register-phone"
                placeholder="+91 1234567890"
                value={formData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="register-password">Password</Label>
              <Input
                id="register-password"
                type="password"
                placeholder="Create a password"
                value={formData.password}
                onChange={(e) => handleInputChange("password", e.target.value)}
              />
            </div>
            <Button
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={handleRegister}
            >
              Create Account
            </Button>
            <p className="text-sm text-center text-gray-600 dark:text-gray-400">
              Already have an account?{" "}
              <button
                onClick={() => setAuthTab("login")}
                className="text-blue-600 hover:underline"
              >
                Login here
              </button>
            </p>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}