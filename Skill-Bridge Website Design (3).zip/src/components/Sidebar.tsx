import { Button } from "./ui/button";
import { 
  Home, 
  LayoutDashboard, 
  User, 
  Zap, 
  Settings, 
  LogOut,
  ChevronLeft,
  ChevronRight,
  MessageCircle,
  Users,
  Briefcase
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onLogout: () => void;
  isOpen: boolean;
  onToggle: () => void;
}

export function Sidebar({ activeTab, onTabChange, onLogout, isOpen, onToggle }: SidebarProps) {
  const navItems = [
    { id: "home", label: "Home", icon: Home },
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "connections", label: "Connections", icon: Users },
    { id: "jobs", label: "Jobs", icon: Briefcase },
    { id: "chat", label: "Messages", icon: MessageCircle },
    { id: "profile", label: "Profile", icon: User },
    { id: "quick-actions", label: "Quick Actions", icon: Zap },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  return (
    <>
      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-16 h-[calc(100vh-4rem)] bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transition-all duration-300 z-40 ${
          isOpen ? "w-64" : "w-0"
        } overflow-hidden`}
      >
        <div className="flex flex-col h-full p-4">
          <nav className="flex-1 space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onTabChange(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeTab === item.id
                      ? "bg-blue-50 dark:bg-blue-900 text-blue-600 dark:text-blue-300"
                      : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          <Button
            variant="outline"
            className="w-full border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
            onClick={onLogout}
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </aside>

      {/* Toggle Button */}
      {!isOpen && (
        <button
          onClick={onToggle}
          className="fixed left-0 top-20 bg-blue-600 text-white p-2 rounded-r-lg z-40 hover:bg-blue-700 transition-colors"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      )}

      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/20 z-30 lg:hidden"
          onClick={onToggle}
        />
      )}
    </>
  );
}