import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { 
  Briefcase, 
  Building2, 
  Users, 
  MessageSquare,
  MapPin,
  DollarSign,
  CheckCircle,
  Clock,
  Calendar,
  TrendingUp
} from "lucide-react";

interface UserDashboardProps {
  user: {
    userType: string;
    fullName: string;
    email: string;
    organization?: string;
    skills?: string;
    experience?: string;
  };
}

export function UserDashboard({ user }: UserDashboardProps) {
  const isWorker = user.userType === "VOLUNTEER";
  const isEmployer = user.userType === "NGO" || user.userType === "CONSTRUCTION" || user.userType === "SERVICE_INDUSTRY";

  // Mock data for demonstration
  const workerStats = {
    applications: 12,
    interviews: 3,
    offers: 1,
    profileViews: 45,
  };

  const employerStats = {
    jobPosts: 5,
    applications: 28,
    shortlisted: 8,
    hired: 2,
  };

  const recentJobs = [
    {
      title: "Carpenter Needed for Residential Project",
      company: "BuildRight Construction",
      location: "Coimbatore",
      salary: "₹25,000 - ₹35,000/month",
      status: "Applied",
    },
    {
      title: "Experienced Plumber Required",
      company: "Modern Homes",
      location: "Coimbatore",
      salary: "₹20,000 - ₹30,000/month",
      status: "Interview Scheduled",
    },
    {
      title: "Electrician - Commercial Projects",
      company: "PowerTech Solutions",
      location: "Coimbatore",
      salary: "₹30,000 - ₹40,000/month",
      status: "Under Review",
    },
  ];

  const applications = [
    {
      name: "Rajesh Kumar",
      skill: "Carpenter",
      experience: "8 years",
      location: "Coimbatore",
      status: "Pending",
      appliedFor: "Senior Carpenter Position",
    },
    {
      name: "Anita Sharma",
      skill: "Chef",
      experience: "5 years",
      location: "Coimbatore",
      status: "Shortlisted",
      appliedFor: "Head Chef",
    },
    {
      name: "Mohamed Ali",
      skill: "Security Guard",
      experience: "3 years",
      location: "Coimbatore",
      status: "Interview",
      appliedFor: "Night Security Guard",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl text-gray-900 mb-2">Dashboard</h1>
          <p className="text-gray-600">
            {isWorker ? "Track your job applications and interviews" : "Manage your job postings and applications"}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {isWorker ? (
            <>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm">Applications Sent</CardTitle>
                  <Briefcase className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl">{workerStats.applications}</div>
                  <p className="text-xs text-gray-500">+2 this week</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm">Interviews</CardTitle>
                  <Calendar className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl">{workerStats.interviews}</div>
                  <p className="text-xs text-gray-500">1 upcoming</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm">Job Offers</CardTitle>
                  <CheckCircle className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl">{workerStats.offers}</div>
                  <p className="text-xs text-gray-500">Awaiting response</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm">Profile Views</CardTitle>
                  <Users className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl">{workerStats.profileViews}</div>
                  <p className="text-xs text-gray-500">+12 this week</p>
                </CardContent>
              </Card>
            </>
          ) : (
            <>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm">Active Job Posts</CardTitle>
                  <Briefcase className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl">{employerStats.jobPosts}</div>
                  <p className="text-xs text-gray-500">2 expiring soon</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm">Applications</CardTitle>
                  <Users className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl">{employerStats.applications}</div>
                  <p className="text-xs text-gray-500">5 new today</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm">Shortlisted</CardTitle>
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl">{employerStats.shortlisted}</div>
                  <p className="text-xs text-gray-500">Ready for interview</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm">Hired</CardTitle>
                  <CheckCircle className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl">{employerStats.hired}</div>
                  <p className="text-xs text-gray-500">This month</p>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Column - Job Management */}
          <div className="lg:col-span-2">
            {isWorker ? (
              <Card>
                <CardHeader>
                  <CardTitle>My Job Applications</CardTitle>
                  <CardDescription>Track your application status</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {recentJobs.map((job, index) => (
                    <div key={index} className="flex items-start justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex-1">
                        <h3 className="text-gray-900 mb-2">{job.title}</h3>
                        <div className="flex flex-wrap gap-4 text-sm text-gray-500">
                          <div className="flex items-center gap-1">
                            <Building2 className="h-4 w-4" />
                            {job.company}
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="h-4 w-4" />
                            {job.location}
                          </div>
                          <div className="flex items-center gap-1">
                            <DollarSign className="h-4 w-4" />
                            {job.salary}
                          </div>
                        </div>
                        <div className="mt-2">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs ${
                            job.status === "Interview Scheduled" 
                              ? "bg-green-100 text-green-800" 
                              : job.status === "Applied"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-gray-100 text-gray-800"
                          }`}>
                            {job.status}
                          </span>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" className="ml-4">
                        View Details
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Recent Applications</CardTitle>
                  <CardDescription>Review and manage applicants</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {applications.map((app, index) => (
                    <div key={index} className="flex items-start justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-start gap-3">
                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                          <Users className="h-6 w-6 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="text-gray-900 mb-1">{app.name}</h3>
                          <p className="text-sm text-gray-600">{app.skill} • {app.experience}</p>
                          <p className="text-sm text-blue-600 mb-1">{app.appliedFor}</p>
                          <div className="flex items-center gap-1 text-sm text-gray-500 mt-1">
                            <MapPin className="h-3 w-3" />
                            {app.location}
                          </div>
                          <div className="mt-2">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs ${
                              app.status === "Interview" 
                                ? "bg-green-100 text-green-800" 
                                : app.status === "Shortlisted"
                                ? "bg-blue-100 text-blue-800"
                                : "bg-gray-100 text-gray-800"
                            }`}>
                              {app.status}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          View Profile
                        </Button>
                        <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                          Contact
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar - Analytics & Actions */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Activity Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">This Week</span>
                    <TrendingUp className="h-4 w-4 text-green-600" />
                  </div>
                  {isWorker ? (
                    <>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Applications Sent</span>
                          <span className="text-blue-600">5</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Responses Received</span>
                          <span className="text-blue-600">3</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Profile Views</span>
                          <span className="text-blue-600">12</span>
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>New Applications</span>
                          <span className="text-blue-600">15</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Interviews Scheduled</span>
                          <span className="text-blue-600">4</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Positions Filled</span>
                          <span className="text-blue-600">2</span>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {isWorker ? (
                  <>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Response Rate</span>
                      <span className="text-green-600">68%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Avg. Response Time</span>
                      <span className="text-gray-900">2.5 days</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Profile Completion</span>
                      <span className="text-blue-600">85%</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Hiring Success Rate</span>
                      <span className="text-green-600">78%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Avg. Time to Hire</span>
                      <span className="text-gray-900">12 days</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Application Quality</span>
                      <span className="text-blue-600">High</span>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
